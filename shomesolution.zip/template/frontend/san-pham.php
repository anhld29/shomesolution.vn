<?php include('header.php') ?>
<script>
    $("body").removeAttr('class');
    $("body").attr('class', "page-product-configurable catalog-product-view product-nem-lo-xo-therapedic-elite-euro-top page-layout-1column loading-active-12");


</script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
<div class="wrapper-breadcrums">
    <div class="breadcrumbs">
        <ul class="items">
            <li class="item home">
                <a href="https://shomesolution.com/" title="Đi đến trang chủ">
                    Trang chủ </a>
            </li>
            <li class="item brands">
                <a href="https://shomesolution.com/brands/" title="Brands">
                    Brands </a>
            </li>
            <li class="item brand">
                <strong>Dunlopillo</strong>
            </li>
        </ul>
    </div>
</div>
<main id="maincontent" class="page-main">


    <a id="contentarea" tabindex="-1"></a>
    <div class="page messages">
        <div data-placeholder="messages"></div>
    </div>
    <div class="columns">
        <div class="column main">
            <div class="product-main-content">
                <div id="product-detail"><!---->
                    <div>
                        <div id="product-detail-main-content" class="product-detail-main-content">
                            <form method="post" action="" class="form-addtocart"><!---->
                                <div options="" class="product-detail-first-block">
                                    <div class="block-detail-top">
                                        <div class="column-left">
                                            <div class="product-images">
                                                <div class="product-image-single"><!---->
                                                    <div class="item image"><img
                                                                src="https://shomesolution.com/media/catalog/product/1/3/13.elite_euro_top.jpg">
                                                        <!----></div>
                                                </div>
                                                <div class="product-image-thumbnail">
                                                    <a class="item-image" data-fancybox="gallery" href="https://shomesolution.com/media/catalog/product/1/3/13.elite_euro_top.jpg"><img class="image-thumbs-effect"
                                                                                 src="https://shomesolution.com/media/catalog/product/1/3/13.elite_euro_top.jpg">
                                                        <!----></a>
                                                    <a class="item-image" data-fancybox="gallery" href="https://shomesolution.com/media/catalog/product/e/l/elite_euro_top_2_.jpg"><img class="image-thumbs-effect"
                                                                                 src="https://shomesolution.com/media/catalog/product/e/l/elite_euro_top_2_.jpg">
                                                        <!----></a>
                                                    <a class="item-image" data-fancybox="gallery" href="https://shomesolution.com/media/catalog/product/e/l/elite_euro_top_3_.jpg"><img class="image-thumbs-effect"
                                                                                 src="https://shomesolution.com/media/catalog/product/e/l/elite_euro_top_3_.jpg">
                                                        <!----></a>
                                                    <a class="item-image" data-fancybox="gallery" href="https://shomesolution.com/media/catalog/product/e/l/elite_euro_top_4_.jpg"><img class="image-thumbs-effect"
                                                                                 src="https://shomesolution.com/media/catalog/product/e/l/elite_euro_top_4_.jpg">
                                                        <!----></a>
                                                    <a class="item-image" data-fancybox="gallery" href="https://shomesolution.com/media/catalog/product/e/l/elite_euro_top_1_.jpg"><img class="image-thumbs"
                                                                                 src="https://shomesolution.com/media/catalog/product/e/l/elite_euro_top_1_.jpg">
                                                        <div class="view-more-image"><span>Xem tất cả<p>(6)</p></span>
                                                        </div>
                                                    </a>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="product-detail"><h1 class="title">Nệm lò xo Therapedic Elite Euro
                                                Top</h1> <!----> <!---->
                                            <div class="intro">
                                                <div class="star">
                                                    <div class="empty-review"><img
                                                                data-src="https://shomesolution.com/static/version1608281598/frontend/Codazon/fastest_furniture/vi_VN/shomesolution_Webpack/css/assets/main-product-detail/pencil.svg"
                                                                src="https://shomesolution.com/static/version1608281598/frontend/Codazon/fastest_furniture/vi_VN/shomesolution_Webpack/css/assets/main-product-detail/pencil.svg"
                                                                lazy="loaded"> Viết nhận xét
                                                    </div>
                                                </div>
                                                <div class="product-brand"><!----><!----><!----><!----><!----><!---->
                                                    <!----><!----><!----><!---->
                                                    <div>
                                                        Hãng: <a href="https://shomesolution.com/brand/amando">Amando</a></div>
                                                    <!----><!----><!----><!----><!----><!----><!----><!----><!---->
                                                    <!----><!----><!----><!----></div>
                                                <div class="product-key">SKU: <span>28150001</span></div>
                                            </div>
                                            <div class="price-status active-freeship">
                                                <div class="price-freeship">
                                                    <div class="final-price"><span
                                                                class="price">20.290.000&nbsp;đ</span></div> <!---->
                                                </div>
                                                <div class="freeship-product">Freeship</div>
                                            </div>
                                            <div class="block-discounts">
                                                <div class="block-discount">Nhập<span>QUAGIANGSINH</span>:&nbsp;Giảm
                                                    200k cho đơn hàng trên 5 triệu
                                                </div>
                                            </div>
                                            <div class="product attibute overview">
                                                <div class="promo-container top hide">
                                                    <div class="img-icon"><img alt="discount5percent"
                                                                               data-src="https://shomesolution.com/static/version1608281598/frontend/Codazon/fastest_furniture/vi_VN/shomesolution_Webpack/css/assets/main-product-detail/discount5percent.svg"
                                                                               src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                               lazy="loading"></div>
                                                    <div class="detail">
                                                        Giảm thêm 5% tối đa 1 triệu khi thanh toán trực tuyến qua
                                                        VNPAY-QR với mã HUYVU5 hoặc giảm
                                                        thêm 10% tối đa 100K với mã
                                                    </div>
                                                </div>
                                                <div class="promo-container bottom hide">
                                                    <div class="img-icon"><img alt="cashback"
                                                                               data-src="https://shomesolution.com/static/version1608281598/frontend/Codazon/fastest_furniture/vi_VN/shomesolution_Webpack/css/assets/main-product-detail/charterd-cashback@2x.svg"
                                                                               src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                                                                               lazy="loading"></div>
                                                    <div class="detail">Giảm thêm 5% tối đa 300k khi thanh toán trực
                                                        tuyến bằng thẻ Standard Chartered Cashback
                                                    </div>
                                                </div>
                                                <div class="options-attribute-product">
                                                    <div class="product-option-mobile-top"><!---->
                                                        <div class="size-thick">
                                                            <div class="items-option"><span class="label"><span>
  Độ dày
</span><span>(cm)</span></span>
                                                                <div data-v-138dff1d="" class="v-select">
                                                                    <button data-v-138dff1d="" type="button"
                                                                            class="v-select-toggle">
                                                                        <div data-v-138dff1d="">28</div>
                                                                        <div data-v-138dff1d=""
                                                                             class="arrow-down"></div>
                                                                    </button>
                                                                    <div data-v-138dff1d="" class="v-dropdown-container"
                                                                         style="display: none;">
                                                                        <div data-v-138dff1d="" class="v-bs-searchbox"
                                                                             style="display: none;"><input
                                                                                    data-v-138dff1d=""
                                                                                    placeholder="Search" type="text"
                                                                                    autofocus="autofocus"
                                                                                    class="form-control"></div>
                                                                        <ul data-v-138dff1d="">
                                                                            <li data-v-138dff1d=""
                                                                                class="v-dropdown-item"
                                                                                style="display: none;">No results
                                                                                matched ""
                                                                            </li> <!---->
                                                                            <li data-v-138dff1d=""
                                                                                class="v-dropdown-item selected">28
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="items-option"><span class="label"><span>
  Kích thước
</span><span>(cm)</span></span>
                                                                <div data-v-138dff1d="" class="v-select">
                                                                    <button data-v-138dff1d="" type="button"
                                                                            class="v-select-toggle">
                                                                        <div data-v-138dff1d="">100x200</div>
                                                                        <div data-v-138dff1d=""
                                                                             class="arrow-down"></div>
                                                                    </button>
                                                                    <div data-v-138dff1d="" class="v-dropdown-container"
                                                                         style="display: none;">

                                                                        <ul data-v-138dff1d="">
                                                                            <li data-v-138dff1d="" class="v-dropdown-item selected">100x200
                                                                            </li>
                                                                            <li data-v-138dff1d="" class="v-dropdown-item">120x200
                                                                            </li>
                                                                            <li data-v-138dff1d=""  class="v-dropdown-item">140x200
                                                                            </li>
                                                                            <li data-v-138dff1d=""
                                                                                class="v-dropdown-item">160x200
                                                                            </li>
                                                                            <li data-v-138dff1d=""
                                                                                class="v-dropdown-item">180x200
                                                                            </li>
                                                                            <li data-v-138dff1d=""
                                                                                class="v-dropdown-item">200x200
                                                                            </li>
                                                                            <li data-v-138dff1d=""
                                                                                class="v-dropdown-item">200x220
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div><!----><!----></div>
                                                        <div class="number-product-block"><!----></div>
                                                    </div> <!----></div>
                                                <div class="number-qty">
                                                    <div class="plus-minus-box">
                                                        <label for="input-group-field" class="label-status"><span>Số lượng</span></label>
                                                        <div class="input-group plus-minus-input">
                                                            <div class="input-group-button">
                                                                <button type="button"
                                                                        class="button hollow circle minus"><i
                                                                            aria-hidden="true" class="fa fa-minus"></i>
                                                                </button>
                                                                <input id="input-group-field" type="number"
                                                                       name="quantity" min="1" max="5" value="1"
                                                                       class="qty-input">

                                                                <button type="button" class="button hollow circle plus">
                                                                    <i aria-hidden="true" class="fa fa-plus"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="status">
                                                        Tình trạng:
                                                        <span class="instock"><span>Còn hàng </span></span></div>
                                                </div> <!---->

                                                <div>
                                                    <div class="actions">
                                                        <div class="button-action">
                                                            <button type="button" title="MUA NGAY"
                                                                    class="set-paymentmethod">Mua trả góp 0% <span>Trả góp qua thẻ tín dụng</span>
                                                            </button>
                                                            <button type="button" title="MUA NGAY"
                                                                    class="set-paymentmethod">Thanh toán VNPAY <span>ATM nội địa | QRcode</span>
                                                            </button>
                                                        </div>
                                                        <div class="button-actions">
                                                            <button type="button" title="MUA NGAY" id="buy-now">
                                                                <div class="text"><!---->
                                                                    Mua ngay<span>Thanh toán tiền mặt khi nhận hàng tại nhà</span>
                                                                </div>
                                                            </button>
                                                        </div>
                                                        <div class="block-find-store"><p class="find-store"></p></div>
                                                    </div>
                                                </div>
                                            </div> <!---->
                                            <div><!----></div>
                                        </div>
                                    </div>
                                    <div class="col-block-right">
                                        <div class="detail-block-right-top"><h3>Lợi ích khi mua hàng tại Vua nệm</h3>
                                            <p><span class="icon"><img
                                                            src="https://media.shomesolution.com/wysiwyg/brand/ic-waranty.png"
                                                            alt=""></span><span class="text"> Bảo hành chính hãng</span>
                                            </p>
                                            <p><span class="icon"><img
                                                            src="https://media.shomesolution.com/wysiwyg/brand/ic-freeship.png"
                                                            alt=""></span> <span class="text">Freeship cho đơn hàng trên 1 triệu trong vòng 30km</span>
                                            </p>
                                            <p><span class="icon"><img
                                                            src="https://media.shomesolution.com/wysiwyg/brand/ic-doitra.png"
                                                            alt=""></span> <span class="text">100 ngày đổi trả tại hệ thống hơn 50 cửa hàng trên toàn quốc</span>
                                            </p>
                                        </div>
                                        <div id="store-detail"><h3>Cửa hàng có sẵn hàng</h3> <select>
                                                <option value="569">Hồ Chí Minh</option>
                                                <option value="570">Hà Nội</option>
                                                <option value="573">Quảng Ninh</option>
                                                <option value="574">Hải Phòng</option>
                                                <option value="577">Phú Thọ</option>
                                                <option value="578">Thái Nguyên</option>
                                                <option value="588">Hải Dương</option>
                                                <option value="589">Ninh Bình</option>
                                                <option value="590">Thanh Hóa</option>
                                                <option value="593">Đà Nẵng</option>
                                                <option value="594">Đăklak</option>
                                                <option value="596">Lâm Đồng</option>
                                                <option value="597">Đồng Nai</option>
                                                <option value="598">Bình Dương</option>
                                                <option value="600">Tiền Giang</option>
                                                <option value="601">Vĩnh Long</option>
                                                <option value="602">Cần Thơ</option>
                                                <option value="603">Đồng Tháp</option>
                                                <option value="604">An Giang</option>
                                                <option value="605">Kiên Giang</option>
                                                <option value="606">Cà Mau</option>
                                                <option value="608">Bến Tre</option>
                                                <option value="609">Bà Rịa Vũng Tàu</option>
                                                <option value="619">Sóc Trăng</option>
                                                <option value="623">Vĩnh Phúc</option>
                                                <option value="624">Hưng Yên</option>
                                                <option value="626">Quảng Nam</option>
                                                <option value="628">Bạc Liêu</option>
                                                <option value="632">Bắc Ninh</option>
                                            </select>
                                            <ul>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.0158442,105.8323351/@21.0158442,105.8323351"
                                                       title="209 Xã Đàn, Quận Đống Đa, Hà Nội" target="_blank">Vua Nệm
                                                        209 Xã Đàn</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/20.998391,105.8664563/@20.998391,105.8664563"
                                                       title="490 Minh Khai, Quận Hai Bà Trưng, Hà Nội" target="_blank">Vua
                                                        Nệm 490 Minh Khai</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.069029,105.807969/@21.069029,105.807969"
                                                       title="72 Võ Chí Công, Quận Cầu Giấy, Hà Nội" target="_blank">Vua
                                                        Nệm 72 Võ Chí Công</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.017959 ,105.802833/@21.017959 ,105.802833"
                                                       title="808 Đường Láng, Quận Đống Đa, Hà Nội" target="_blank">Vua
                                                        Nệm 808 Đường Láng</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/20.9985405,105.8659709/@20.9985405,105.8659709"
                                                       title="Đường 4, dãy 9, TTTM Vincom MegaMall Times City, 458 Minh Khai, Quận Hai Bà Trưng, Hà Nội"
                                                       target="_blank">Vua Nệm Times City</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.051188,105.885296/@21.051188,105.885296"
                                                       title="576 Nguyễn Văn Cừ, Quận Long Biên, Hà Nội"
                                                       target="_blank">Vua Nệm 576 Nguyễn Văn Cừ</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.010511,105.810633/@21.010511,105.810633"
                                                       title="23 Lê Văn Lương, Quận Thanh Xuân, Hà Nội" target="_blank">Vua
                                                        Nệm 23 Lê Văn Lương</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/20.9710223,105.8335465/@20.9710223,105.8335465"
                                                       title="96 Nguyễn Hữu Thọ, Quận Hoàng Mai, Hà Nội"
                                                       target="_blank">Vua Nệm 96 Nguyễn Hữu Thọ</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.0347415,105.7627529/@21.0347415,105.7627529"
                                                       title="189 Hàm Nghi , Quận Nam Từ Liêm, Hà Nội" target="_blank">Vua
                                                        Nệm 189 Hàm Nghi </a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.014151,105.790550/@21.014151,105.790550"
                                                       title="142 Nguyễn Chánh, Quận Cầu Giấy, Hà Nội" target="_blank">Vua
                                                        Nệm 142 Nguyễn Chánh</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.064127,105.7125949/@21.064127,105.7125949"
                                                       title="Quốc Lộ 32, Khu công nghiệp Lai Xá, Huyện Hoài Đức, Hà Nội"
                                                       target="_blank">Vua Nệm Quốc lộ 32 Khu công nghiệp Lai Xá</a>
                                                </li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.002471,105.8130491/@21.002471,105.8130491"
                                                       title="Royal City 72A Nguyễn Trãi, Quận Thanh Xuân, Hà Nội"
                                                       target="_blank">Vua Nệm Royal City</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.002908,105.8403693/@21.002908,105.8403693"
                                                       title="21 Giải Phóng, Quận Hai Bà Trưng, Hà Nội" target="_blank">Vua
                                                        Nệm 21 Giải Phóng</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.0071903,105.7370668/@21.0071903,105.7370668"
                                                       title="01SH15 tòa S2-05 Smart City, Tây Mỗ, Quận Nam Từ Liêm, Hà Nội"
                                                       target="_blank">Vua Nệm Smart City</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/20.9997169,105.9510487/@20.9997169,105.9510487"
                                                       title="01SH05 toà S2-11 Ocean Park, Huyện Gia Lâm, Hà Nội"
                                                       target="_blank">Vua Nệm Ocean Park</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/20.9949804,105.7874617/@20.9949804,105.7874617"
                                                       title="Tầng 1&amp;2, tòa CT1, C14 Bắc Hà, Tố Hữu, P. Trung Văn, Quận Nam Từ Liêm, Hà Nội"
                                                       target="_blank">Gian hàng Vua Nệm chung cư C14 Bắc Hà</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/20.9940686,105.8041294/@20.9940686,105.8041294"
                                                       title="378 Nguyễn Trãi, P. Thanh Xuân Trung, Quận Thanh Xuân, Hà Nội"
                                                       target="_blank">Vua Nệm 378 Nguyễn Trãi</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/20.9824899,105.7675595/@20.9824899,105.7675595"
                                                       title="Shophouse B2-22 Tố Hữu, Phường Vạn Phúc, Quận Hà Đông, Hà Nội"
                                                       target="_blank">Vua Nệm 22 Tố Hữu</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.012603,105.8562073/@21.012603,105.8562073"
                                                       title="142 Lò Đúc, Phường Đống Mác, Quận Hai Bà Trưng, Hà Nội"
                                                       target="_blank">Vua Nệm 142 Lò Đúc</a></li>
                                                <li>
                                                    <a href="https://www.google.com/maps/dir/__origLatitude__,__origLongitude__/21.0386715,105.7880944/@21.0386715,105.7880944"
                                                       title="85 Nguyễn Phong Sắc, Quận Cầu Giấy, Hà Nội"
                                                       target="_blank">Vua Nệm 85 Nguyễn Phong Sắc</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div> <!----> <!----></form>
                            <div class="overlay-option"></div>
                        </div>
                        <div id="product-detail-product-info-detail" class="product-detail-product-info-detail">
                            <div class="product-features widget block block-static-block">
                                <div>
                                    <div class="head-block"><h2 class="title-block font-bold-stag">SẢN PHẨM BÁN
                                            CHẠY</h2></div>
                                    <div class="content-block block-products-list">
                                        <div class="style-2 products-grid slick-initialized slick-slider">
                                            <div class="slick-prev slick-arrow" aria-label="Previous" style=""></div>
                                            <div class="slick-list draggable">
                                                <div class="slick-track"
                                                     style="opacity: 1; width: 5328px; transform: translate3d(-1184px, 0px, 0px);">
                                                    <div class="slick-slide slick-cloned" data-slick-index="-4" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/7/_/7._rhapsody_in_blue.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Therapedic Rhapsody in Blue</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">57.890.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="-3" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/3/_/3.evita.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Evita</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">26.091.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="-2" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/2/_/2.elizabeth.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Elizabeth</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">33.251.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="-1" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/1/_/1.royal_kensington.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Royal Kensington</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">49.660.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-current slick-active"
                                                         data-slick-index="0" aria-hidden="false" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-cambridge-luxe.html"
                                                                                    tabindex="0"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/c/a/cambridge-luxe-web_1.jpg">
                                                                                <!----></a>
                                                                            <div class="discount-percent">-25%</div>
                                                                        </div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-cambridge-luxe.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="0">Nệm Lò xo
                                                                                    Dunlopillo Cambridge Luxe</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">34.968.750&nbsp;đ</span>
                                                                                    </div>
                                                                                    <div class="old-price">
                                                                                        <div class="normal-price"><span
                                                                                                    class="price">46.625.000&nbsp;đ</span>
                                                                                        </div>
                                                                                        <div class="discount-price">Tiết
                                                                                            kiệm 11.656.250 đ
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-cambridge-luxe.html"
                                                                                        tabindex="0">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-active" data-slick-index="1"
                                                         aria-hidden="false" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-therapedic-premium-innergy.html"
                                                                                    tabindex="0"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/t/h/thera_innergy.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-premium-innergy.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="0">Nệm lò xo
                                                                                    Therapedic Premium Innergy</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">25.916.666&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-premium-innergy.html"
                                                                                        tabindex="0">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-active" data-slick-index="2"
                                                         aria-hidden="false" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-therapedic-therawrap-plus.html"
                                                                                    tabindex="0"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/t/h/therawrap_plus.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-therawrap-plus.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="0">Nệm lò xo
                                                                                    Therapedic Therawrap Plus</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">34.877.778&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-therawrap-plus.html"
                                                                                        tabindex="0">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-active" data-slick-index="3"
                                                         aria-hidden="false" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                    tabindex="0"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/7/_/7._rhapsody_in_blue.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="0">Nệm lò xo
                                                                                    Therapedic Rhapsody in Blue</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">57.890.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                        tabindex="0">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide" data-slick-index="4" aria-hidden="true"
                                                         tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/3/_/3.evita.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Evita</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">26.091.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide" data-slick-index="5" aria-hidden="true"
                                                         tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/2/_/2.elizabeth.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Elizabeth</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">33.251.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide" data-slick-index="6" aria-hidden="true"
                                                         tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/1/_/1.royal_kensington.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Royal Kensington</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">49.660.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="7" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-cambridge-luxe.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/c/a/cambridge-luxe-web_1.jpg">
                                                                                <!----></a>
                                                                            <div class="discount-percent">-25%</div>
                                                                        </div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-cambridge-luxe.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm Lò xo
                                                                                    Dunlopillo Cambridge Luxe</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">34.968.750&nbsp;đ</span>
                                                                                    </div>
                                                                                    <div class="old-price">
                                                                                        <div class="normal-price"><span
                                                                                                    class="price">46.625.000&nbsp;đ</span>
                                                                                        </div>
                                                                                        <div class="discount-price">Tiết
                                                                                            kiệm 11.656.250 đ
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-cambridge-luxe.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="8" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-therapedic-premium-innergy.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/t/h/thera_innergy.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-premium-innergy.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Therapedic Premium Innergy</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">25.916.666&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-premium-innergy.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="9" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-therapedic-therawrap-plus.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/t/h/therawrap_plus.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-therawrap-plus.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Therapedic Therawrap Plus</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">34.877.778&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-therawrap-plus.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="10" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/7/_/7._rhapsody_in_blue.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Therapedic Rhapsody in Blue</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">57.890.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-therapedic-rhapsody-in-blue.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="11" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/3/_/3.evita.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Evita</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">26.091.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-evita.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="12" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/2/_/2.elizabeth.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Elizabeth</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">33.251.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-elizabeth.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-cloned" data-slick-index="13" id=""
                                                         aria-hidden="true" tabindex="-1" style="width: 296px;">
                                                        <div>
                                                            <div class="product-items"
                                                                 style="width: 100%; display: inline-block;">
                                                                <div class="product-item">
                                                                    <div class="product-item-info">
                                                                        <div class="cdz-product-top"><a
                                                                                    href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                    tabindex="-1"><!----><!----><!---->
                                                                                <!----><img
                                                                                        src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/1/_/1.royal_kensington.jpg">
                                                                                <!----></a> <!----></div>
                                                                        <div class="product details product-item-details active-freeship">
                                                                            <h3 class="product-item-link"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                        class="product-item-link"
                                                                                        tabindex="-1">Nệm lò xo
                                                                                    Dunlopillo Royal Kensington</a></h3>
                                                                            <div class="price-freeship">
                                                                                <div class="price-product price-box price-final_price">
                                                                                    <div class="new-price"><span
                                                                                                class="price">49.660.000&nbsp;đ</span>
                                                                                    </div> <!----></div>
                                                                                <div class="freeship-product">Freeship
                                                                                </div>
                                                                            </div>
                                                                            <div class="view-detail"><a
                                                                                        href="https://shomesolution.com/nem-lo-xo-dunlopillo-royal-kensington.html"
                                                                                        tabindex="-1">Mua Ngay</a></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="slick-next slick-arrow" aria-label="Next" style=""></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="product-info-detailed">
                                <div class="main-column">
                                    <div class="main-description-product">
                                        <div class="head-block"><h2 class="title-block">Đặc điểm sản phẩm</h2></div>
                                        <div class="content-block main-description"><!---->
                                            <div class="additional-attributes-product">
                                                <div class="content-blocks">
                                                    <div class="additional-attributes">
                                                        <div class="attribute-item">
                                                            <div scope="row" class="col label"><span>
  Loại Sản Phẩm
</span></div>
                                                            <div class="col data">Spring Matress</div>
                                                        </div>
                                                        <div class="attribute-item">
                                                            <div scope="row" class="col label"><span>
  Độ Cứng Mềm
</span></div>
                                                            <div class="col data">Cứng</div>
                                                        </div>
                                                        <div class="attribute-item">
                                                            <div scope="row" class="col label"><span>
  Chất Liệu
</span></div>
                                                            <div class="col data">Lò xo túi</div>
                                                        </div>
                                                        <div class="attribute-item">
                                                            <div scope="row" class="col label"><span>
  Đặc Điểm
</span></div>
                                                            <div class="col data">Nệm thẳng</div>
                                                        </div>
                                                        <div class="attribute-item">
                                                            <div scope="row" class="col label"><span>
  Thương Hiệu
</span></div>
                                                            <div class="col data">Therapedic</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="description-view-content cọntent-desctiption hide-content">
                                                <div class="cọntent-desctiptions">
                                                    <section class="section title-product">
                                                        <div class="section-content relative">
                                                            <h3>
                                                                <span id="docs-internal-guid-eefa0a41-7fff-c4e4-1b70-cf9307e98cf4"
                                                                      style="color: #2b3984;"><span
                                                                            id="docs-internal-guid-0721adb3-7fff-1060-41e5-36985bd41ee5"><span
                                                                                id="docs-internal-guid-a91d46ed-7fff-fd39-db0e-6bf4c8205735"><span
                                                                                    id="docs-internal-guid-2746e8b1-7fff-1a1f-0979-731f2b936c62"><span>Sự lựa chọn sáng suốt cho các trải nghiệm giấc ngủ!</span></span></span></span></span><span
                                                                        style="color: #2b3984;">!</span></h3>
                                                            <p style="text-align: center;"><span
                                                                        id="docs-internal-guid-e9a0b2a1-7fff-7165-79c1-4c0fc88f7dd7"
                                                                        style="font-size: medium; font-family: arial, helvetica, sans-serif; color: #000000;"><span
                                                                            id="docs-internal-guid-32593441-7fff-fcb1-c7da-123b72e3ef1a"><span
                                                                                id="docs-internal-guid-99ec2ccb-7fff-ee01-a38e-024c3a39b6bb"><span
                                                                                    id="docs-internal-guid-121dfcb5-7fff-40c2-6565-7c883b036c03"><span><span
                                                                                            id="docs-internal-guid-6db3ab14-7fff-8f44-fd3a-693040a05040"><a
                                                                                                href="https://shomesolution.com/nem-lo-xo-therapedic-elite-euro-top.html"
                                                                                                target="_blank">Nệm lò xo Therapedic Elite Euro Top</a> là một trong các dòng nệm sở hữu công nghệ HourGlass Support tăng cường hỗ trợ thêm các vùng nặng nhất của cơ thể bao gồm 13% ở lưng, 18% ở vai và hông</span></span></span></span></span>.</span>
                                                            </p>
                                                            <br>
                                                            <p>
                                                                <img src="https://media.shomesolution.com/wysiwyg/blog/Detail/EURO_TOP-1_-_Copy.png"
                                                                     alt="Nệm lò xo Therapedic Elite Euro Top"
                                                                     width="1588" height="728"></p>
                                                        </div>
                                                    </section>
                                                    <section class="section information-product">
                                                        <h3 class="section-title"><span style="color: #2b3984;">Thông tin chi tiết sản phẩm</span>
                                                        </h3>
                                                        <div class="section-content relative">
                                                            <div class="item-des-product">
                                                                <div class="row"><span><span></span></span>
                                                                    <p dir="ltr" style="text-align: justify;">
                                                                        <span><span></span></span></p>
                                                                    <p dir="ltr" style="text-align: justify;">
                                                                        <span><span></span></span></p>
                                                                    <p dir="ltr" style="text-align: justify;">
                                                                        <span><span></span></span></p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #2d2e7f;"><strong><span
                                                                                        style="font-size: medium; font-family: arial, helvetica, sans-serif;">Hệ thống lò xo Backsense®: </span></strong></span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #000000; font-size: medium; font-family: arial, helvetica, sans-serif;">Hệ thống lò xo túi siêu nhỏ tự điều chỉnh linh hoạt trên từng cử động nhỏ nhất, giúp định hình chính xác tư thế người nằm đến từng milimet và hỗ trợ nâng đỡ tối ưu.</span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="font-family: arial, helvetica, sans-serif; font-size: medium; color: #2d2e7f;"><strong>Công nghệ HourGlass Support:</strong></span><span
                                                                                style="color: #000000; font-family: arial, helvetica, sans-serif; font-size: medium;"> các vùng nâng đỡ khác nhau của hệ thống đồng hồ cát này giúp bảo vệ tốt các vùng chiếm trọng lượng nặng, đó là vùng lưng và hông. Thêm vào đó, vùng thắt lưng mềm mại của bạn cũng được nhẹ nhàng gia cố.</span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><img
                                                                                src="https://media.shomesolution.com/wysiwyg/blog/Detail/Eurotop_-_Copy.jpg"
                                                                                alt="Nệm lò xo Therapedic Elite Euro Top"
                                                                                width="1080" height="804"></p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #000000; font-size: medium; font-family: arial, helvetica, sans-serif;"><span
                                                                                    style="color: #2d2e7f;"><strong>Độ bền cao:</strong></span> </span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #000000; font-size: medium; font-family: arial, helvetica, sans-serif;">Hệ thống lò xo cứng cáp tạo cho thành nệm độ vững vàng, hạn chế bị xẹp lún theo thời gian.</span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #000000; font-size: medium; font-family: arial, helvetica, sans-serif;"><span
                                                                                    style="color: #2d2e7f;"><strong>Nâng đỡ mềm mại</strong></span></span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #000000; font-size: medium; font-family: arial, helvetica, sans-serif;">Lớp Memory foam Backsense™ có độ đàn hồi hoàn hảo, tương thích mọi dáng nằm của cơ thể, phù hợp với cả những người có các bệnh về xương khớp hoặc cột sống, giúp người nằm có giấc ngủ thoải mái và dễ chịu hơn.</span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #000000; font-size: medium; font-family: arial, helvetica, sans-serif;"><span
                                                                                    style="color: #2d2e7f;"><strong>Hướng dẫn sử dụng</strong></span>: Để sản phẩm được bền lâu với thời gian, người dùng nên:</span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #000000; font-size: medium; font-family: arial, helvetica, sans-serif;">- Đặt sản phẩm <a
                                                                                    href="https://shomesolution.com/nem/lo-xo"
                                                                                    target="_blank">nệm lò xo</a> ở bề mặt phẳng, khô ráo và thoáng mát</span>
                                                                    </p>
                                                                    <p dir="ltr" style="text-align: justify;"><span
                                                                                style="color: #000000; font-size: medium; font-family: arial, helvetica, sans-serif;">- Không để sản phẩm tiếp xúc với dung môi, axit, vật liệu dễ cháy…</span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </section>
                                                    <style xml="space"><!--
                                                        .additional-attributes-wrapper.table-wrapper {
                                                            display: none;
                                                        }

                                                        .product.attribute.description {
                                                            width: 100%;
                                                            font-family: "Open Sans", sans-serif;
                                                        }

                                                        .product.attribute.description [class*="col-"] {
                                                            position: relative;
                                                            margin: 0;
                                                            padding: 0 15px;
                                                            width: 100%;
                                                        }

                                                        .product.attribute.description .row {
                                                            width: 100%;
                                                            margin: 0;
                                                            -js-display: flex;
                                                            display: -ms-flexbox;
                                                            display: flex;
                                                            -ms-flex-flow: row wrap;
                                                            flex-flow: row wrap;
                                                            -ms-flex-align: center !important;
                                                            align-items: center !important;
                                                            -ms-flex-item-align: center !important;
                                                            -ms-grid-row-align: center !important;
                                                            align-self: center !important;
                                                            vertical-align: middle !important;
                                                        }

                                                        .col-3 {
                                                            -webkit-box-flex: 0;
                                                            -ms-flex: 0 0 25%;
                                                            flex: 0 0 25%;
                                                            max-width: 25%;
                                                        }

                                                        .col-4 {
                                                            -webkit-box-flex: 0;
                                                            -ms-flex: 0 0 33.333%;
                                                            flex: 0 0 33.333%;
                                                            max-width: 33.333%;
                                                        }

                                                        .col-9 {
                                                            -webkit-box-flex: 0;
                                                            -ms-flex: 0 0 75%;
                                                            flex: 0 0 75%;
                                                            max-width: 75%;
                                                        }

                                                        .service-product {
                                                            width: 70%;
                                                            margin: 0 auto;
                                                        }

                                                        .title-product {
                                                            text-align: center
                                                        }

                                                        .title-product h3 {
                                                            font-size: 20px;
                                                            font-weight: 600;
                                                        }

                                                        .more-infor .box-text {
                                                            padding: 10px
                                                        }

                                                        .more-infor .box-text h4 {
                                                            margin-bottom: 0;
                                                            font-weight: 500;
                                                        }

                                                        .service-product .box-image {
                                                            margin: 0 auto;
                                                        }

                                                        .service-product .box-text-inner {
                                                            margin-top: 10px
                                                        }

                                                        .service-product p {
                                                            margin: 0
                                                        }

                                                        .information-product .section-title {
                                                            text-align: center;
                                                            z-index: 9;
                                                            font-size: 20px;
                                                            font-weight: 600;
                                                            color: #555;
                                                            text-transform: uppercase;
                                                            position: relative;
                                                        }

                                                        .information-product .section-title:before, .information-product .section-title:after {
                                                            content: "";
                                                            display: block;
                                                            width: 25%;
                                                            height: 2px;
                                                            opacity: .1;
                                                            background-color: currentColor;
                                                            position: absolute;
                                                            top: 12px;
                                                        }

                                                        .information-product .section-title:after {
                                                            right: 0;
                                                        }

                                                        .information-product .section-content {
                                                            margin: 20px 0;
                                                            color: #333;
                                                        }

                                                        .information-product .section-content .item-des-product:not(:last-child) {
                                                            border-bottom: 2px solid #eee;
                                                            margin-bottom: 30px
                                                        }

                                                        .information-product .section-content .item-des-product .label-product {
                                                            font-weight: 400;
                                                            font-family: "Open Sans", sans-serif;
                                                            font-size: 26px;

                                                        }

                                                        .information-product .section-content .item-des-product .roimportantw {
                                                            -ms-flex-align: center;
                                                            align-items: center;
                                                            -ms-flex-item-align: center;
                                                            -ms-grid-row-align: center;
                                                            align-self: center;
                                                            vertical-align: middle;
                                                        }

                                                        .information-product .section-content .item-des-product .des-product {
                                                            font-size: 16px;
                                                            line-height: 25px
                                                        }

                                                        .information-product .section-content .item-des-product .des-product b {
                                                            font-weight: 600;
                                                        }

                                                        @media (max-width: 767px) {
                                                            .information-product .section-content .item-des-product:not(:last-child) {
                                                                padding-bottom: 30px;
                                                            }

                                                            .product.attribute.description [class*="col-"] {
                                                                padding: 0 8px;
                                                            }

                                                            .item-service {
                                                                display: none;
                                                            }

                                                            .col-mobile {
                                                                -webkit-box-flex: 0;
                                                                -ms-flex: 0 0 100%;
                                                                flex: 0 0 100%;
                                                                max-width: 100%;
                                                            }

                                                            .information-product .section-content {
                                                                margin: 30px 0;
                                                            }
                                                        }

                                                        @media (max-width: 767px) and (min-width: 480px) {
                                                            .more-infor {
                                                                display: none;
                                                            }
                                                        }

                                                        @media (max-width: 479px ) {
                                                            .col-small-mobile {
                                                                -webkit-box-flex: 0;
                                                                -ms-flex: 0 0 100%;
                                                                flex: 0 0 100%;
                                                                max-width: 100%;
                                                            }

                                                        }

                                                        --></style>
                                                </div>
                                            </div>
                                            <div class="load-more view-mores">
                                                <div class="background-loadmore"></div>
                                                <a class="learn-more"><span class="circle"><span
                                                                class="icon arrow"></span></span> <span
                                                            class="button-text">Xem thêm</span></a></div>
                                        </div>
                                    </div>
                                    <div id="reviews" class="customer-review">
                                        <div id="add-review" class="add-customer-review">
                                            <div class="content-block">
                                                <form id="review-form" class="review-form">
                                                    <div class="mark-star">
                                                        <div class="product-infor-bottom"><img
                                                                    src="https://shomesolution.com/pub/media/catalog/product/1/3/13.elite_euro_top.jpg">
                                                            <h3 class="title">Nệm lò xo Therapedic Elite Euro Top</h3>
                                                        </div>
                                                        <fieldset class="field required review-field-ratings">
                                                            <div class="control">
                                                                <div id="product-review-table" class="nested">
                                                                    <div class="field choice review-field-rating">
                                                                        <div class="number-rating font-bold-stag">0/5
                                                                        </div>
                                                                        <div class="control review-control-vote"><input
                                                                                    type="radio" name="ratings"
                                                                                    id="Đánh_giá_tổng_thể_1" value="1"
                                                                                    class="radio"> <label
                                                                                    for="Đánh_giá_tổng_thể_1"
                                                                                    title="1 star"
                                                                                    id="Đánh_giá_tổng_thể_1_label"
                                                                                    class="rating-1"><span>1 star</span></label>
                                                                            <input type="radio" name="starRating"
                                                                                   id="Đánh_giá_tổng_thể_2" value="2"
                                                                                   class="radio"> <label
                                                                                    for="Đánh_giá_tổng_thể_2"
                                                                                    title="2 stars"
                                                                                    id="Đánh_giá_tổng_thể_2_label"
                                                                                    class="rating-2"><span>2 stars</span></label>
                                                                            <input type="radio" name="starRating"
                                                                                   id="Đánh_giá_tổng_thể_3" value="3"
                                                                                   class="radio"> <label
                                                                                    for="Đánh_giá_tổng_thể_3"
                                                                                    title="3 stars"
                                                                                    id="Đánh_giá_tổng_thể_3_label"
                                                                                    class="rating-3"><span>3 stars</span></label>
                                                                            <input type="radio" name="starRating"
                                                                                   id="Đánh_giá_tổng_thể_4" value="4"
                                                                                   class="radio"> <label
                                                                                    for="Đánh_giá_tổng_thể_4"
                                                                                    title="4 stars"
                                                                                    id="Đánh_giá_tổng_thể_4_label"
                                                                                    class="rating-4"><span>4 stars</span></label>
                                                                            <input type="radio" name="starRating"
                                                                                   id="Đánh_giá_tổng_thể_5" value="5"
                                                                                   class="radio"> <label
                                                                                    for="Đánh_giá_tổng_thể_5"
                                                                                    title="5 stars"
                                                                                    id="Đánh_giá_tổng_thể_5_label"
                                                                                    class="rating-5"><span>5 stars</span></label>
                                                                            <span class="error-validate"></span></div>
                                                                        <div class="review-text font-bold-stag">Đánh
                                                                            giá
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <input type="hidden" name="validate_rating" value=""
                                                                       class="validate-rating"></div>
                                                        </fieldset>
                                                    </div>
                                                    <div class="add-review">
                                                        <fieldset class="fieldset review-fieldset"><span
                                                                    id="input-message-box"></span>
                                                            <div class="first-row">
                                                                <div class="field review-field-nickname">
                                                                    <div class="control"><input name="nickname"
                                                                                                type="text"
                                                                                                placeholder="Tên của bạn"
                                                                                                id="nickname_field"
                                                                                                class="input-text review-input">
                                                                        <span class="error-validate"></span></div>
                                                                </div>
                                                                <div class="field review-field-summary"
                                                                     style="display: none;">
                                                                    <div class="control"><input name="title" type="text"
                                                                                                placeholder="Tiêu đề"
                                                                                                id="summary_field"
                                                                                                class="input-text review-input">
                                                                        <span class="error-validate"></span></div>
                                                                </div>
                                                            </div>
                                                            <div class="field review-field-text">
                                                                <div class="control"><textarea name="detail"
                                                                                               id="review_field"
                                                                                               placeholder="Nhập nội dung tại đây"
                                                                                               class=""></textarea>
                                                                    <span class="error-validate"></span></div>
                                                            </div>
                                                        </fieldset>
                                                        <button type="button" class="action submit review-form-actions">
                                                            <span>Gửi nhận xét</span></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <div class="product-review-bottom">
                                            <div class="head-block">
                                                <div class="title-block">
                                                    <span>Phản Hồi Khách hàng (<span>1</span>)</span> <!----></div>
                                            </div>

                                            <div class="content-block">
                                                <div class="review-wrapper">
                                                    <div class="items-review">
                                                        <div class="review">
                                                            <div class="review-container">
                                                                <div class="avatar">
                                                                    <div aria-hidden="true" class="vue-avatar--wrapper"
                                                                         style="display: flex; width: 80px; height: 80px; border-radius: 50%; font: 32px / 80px Helvetica, Arial, sans-serif; align-items: center; justify-content: center; text-align: center; user-select: none; background-color: rgb(255, 152, 0); color: rgb(255, 232, 80);">
                                                                        <!----> <span>BNS</span></div>
                                                                </div>
                                                                <div class="detail"><p
                                                                            class="title-comment font-bold-stag"><span>Viet nam </span>
                                                                        <!----></p>
                                                                    <p class="comment">Toi rat hai long </p></div>
                                                            </div>
                                                            <div class="customer"><p>Bui ngoc sang</p>
                                                                <p>12/08/2020</p></div>
                                                        </div>
                                                    </div>
                                                    <div class="items-review">
                                                        <div class="review">
                                                            <div class="review-container">
                                                                <div class="avatar">
                                                                    <div aria-hidden="true" class="vue-avatar--wrapper"
                                                                         style="display: flex; width: 80px; height: 80px; border-radius: 50%; font: 32px / 80px Helvetica, Arial, sans-serif; align-items: center; justify-content: center; text-align: center; user-select: none; background-color: rgb(255, 152, 0); color: rgb(255, 232, 80);">
                                                                        <!----> <span>BNS</span></div>
                                                                </div>
                                                                <div class="detail"><p
                                                                            class="title-comment font-bold-stag"><span>Viet nam </span>
                                                                        <!----></p>
                                                                    <p class="comment">Toi rat hai long </p></div>
                                                            </div>
                                                            <div class="customer"><p>Bui ngoc sang</p>
                                                                <p>12/08/2020</p></div>
                                                        </div>
                                                    </div>
                                                </div> <!----></div>
                                        </div>
                                        <div class="block-question-detail"></div>
                                    </div>
                                </div>
                                <div class="right-column block-products-list">
                                    <div class="product-related  widget block block-static-block">
                                        <div class="head-block">
                                            <div class="title-block ">Sản phẩm Hot</div>
                                        </div>
                                        <div class="content-block  products-grid">
                                            <div class="block-products-list">
                                                <div class="product-items">
                                                    <div class="product-item">
                                                        <div class="product-item-info">
                                                            <div class="image-product"><a
                                                                        href="https://shomesolution.com/nem-lo-xo-amando-rico.html">
                                                                    <!----><!----><!----><!----><img
                                                                            src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/e/6/e6a8bc4e56d7b189e8c6.jpg">
                                                                    <!----></a> <!----></div>
                                                            <div class="product details product-item-details active-freeship">
                                                                <h3 class="product-item-link"><a
                                                                            href="https://shomesolution.com/nem-lo-xo-amando-rico.html"
                                                                            class="product-item-link">Nệm lò xo Amando
                                                                        Rico</a></h3>
                                                                <div class="price-freeship">
                                                                    <div class="price-product price-box price-final_price">
                                                                        <div class="new-price"><span class="price">7.450.000&nbsp;đ</span>
                                                                        </div> <!----></div>
                                                                    <div class="freeship-product">Freeship</div>
                                                                </div>
                                                                <div class="view-detail"><a
                                                                            href="https://shomesolution.com/nem-lo-xo-amando-rico.html">Mua
                                                                        Ngay</a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-items">
                                                    <div class="product-item">
                                                        <div class="product-item-info">
                                                            <div class="image-product"><a
                                                                        href="https://shomesolution.com/nem-lo-xo-amando-orlando.html">
                                                                    <!----><!----><!----><!----><img
                                                                            src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/o/r/orlando-web-5.jpg">
                                                                    <!----></a>
                                                                <div class="discount-percent">-50%</div>
                                                            </div>
                                                            <div class="product details product-item-details active-freeship">
                                                                <h3 class="product-item-link"><a
                                                                            href="https://shomesolution.com/nem-lo-xo-amando-orlando.html"
                                                                            class="product-item-link">Nệm Lò xo Amando
                                                                        Orlando</a></h3>
                                                                <div class="price-freeship">
                                                                    <div class="price-product price-box price-final_price">
                                                                        <div class="new-price"><span class="price">8.750.000&nbsp;đ</span>
                                                                        </div>
                                                                        <div class="old-price">
                                                                            <div class="normal-price"><span
                                                                                        class="price">17.500.000&nbsp;đ</span>
                                                                            </div>
                                                                            <div class="discount-price">Tiết kiệm
                                                                                8.750.000 đ
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="freeship-product">Freeship</div>
                                                                </div>
                                                                <div class="view-detail"><a
                                                                            href="https://shomesolution.com/nem-lo-xo-amando-orlando.html">Mua
                                                                        Ngay</a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-items">
                                                    <div class="product-item">
                                                        <div class="product-item-info">
                                                            <div class="image-product"><a
                                                                        href="https://shomesolution.com/nem-lo-xo-amando-mario.html">
                                                                    <!----><!----><!----><!----><img
                                                                            src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/a/m/amando-mario-web.jpg">
                                                                    <!----></a> <!----></div>
                                                            <div class="product details product-item-details active-freeship">
                                                                <h3 class="product-item-link"><a
                                                                            href="https://shomesolution.com/nem-lo-xo-amando-mario.html"
                                                                            class="product-item-link">Nệm Lò xo Amando
                                                                        Mario</a></h3>
                                                                <div class="price-freeship">
                                                                    <div class="price-product price-box price-final_price">
                                                                        <div class="new-price"><span class="price">3.750.000&nbsp;đ</span>
                                                                        </div> <!----></div>
                                                                    <div class="freeship-product">Freeship</div>
                                                                </div>
                                                                <div class="view-detail"><a
                                                                            href="https://shomesolution.com/nem-lo-xo-amando-mario.html">Mua
                                                                        Ngay</a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-items">
                                                    <div class="product-item">
                                                        <div class="product-item-info">
                                                            <div class="image-product"><a
                                                                        href="https://shomesolution.com/nem-lo-xo-amando-lucio.html">
                                                                    <!----><!----><!----><!----><img
                                                                            src="https://shomesolution.com/media/catalog/product/cache/c430e3e26517992a27628ce5995d6769/1/d/1d70a7c3da10224e7b01.jpg">
                                                                    <!----></a>
                                                                <div class="discount-percent">-30%</div>
                                                            </div>
                                                            <div class="product details product-item-details active-freeship">
                                                                <h3 class="product-item-link"><a
                                                                            href="https://shomesolution.com/nem-lo-xo-amando-lucio.html"
                                                                            class="product-item-link">Nệm Lò xo Amando
                                                                        Lucio</a></h3>
                                                                <div class="price-freeship">
                                                                    <div class="price-product price-box price-final_price">
                                                                        <div class="new-price"><span class="price">4.130.000&nbsp;đ</span>
                                                                        </div>
                                                                        <div class="old-price">
                                                                            <div class="normal-price"><span
                                                                                        class="price">5.900.000&nbsp;đ</span>
                                                                            </div>
                                                                            <div class="discount-price">Tiết kiệm
                                                                                1.770.000 đ
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="freeship-product">Freeship</div>
                                                                </div>
                                                                <div class="view-detail"><a
                                                                            href="https://shomesolution.com/nem-lo-xo-amando-lucio.html">Mua
                                                                        Ngay</a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><!----><!----><!----></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <script>
                require([
                    'tooltip',
                    'jquery'
                ], function (tooltip, $) {
                    if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                        $('.ampromo-banner-top-img').each(function (key, image) {
                            tooltip({
                                tooltipClass: "ampromo-banner-tooltip",
                                content: function () {
                                    return $('#' + this.id + '-data').html();
                                },
                            }, image);
                        });
                    }
                });
            </script>



        </div>
    </div>
</main>
<script>
    $('.v-select-toggle').click(function () {
        $('.v-dropdown-container').hide();
        $(this).parent().find('.v-dropdown-container').show()

    });
    $('.load-more').click(function () {
        $('.description-view-content').removeClass('hide-content');
        $('.load-more').hide();

    });

    $('[data-fancybox="gallery"]').fancybox({

        buttons: [
            "slideShow",
            'fullScreen',
            'thumbs',
            'zoom',
            "close"
        ],



        thumbs: {
            autoStart: true, // Display thumbnails on opening
            hideOnClose: true, // Hide thumbnail grid when closing animation starts
        },

    });
</script>
<style type="text/css">
    *[data-v-138dff1d] {
        box-sizing: border-box;
    }
    input[data-v-138dff1d] {
        width: 100%;
    }
    ul[data-v-138dff1d] {
        font-size: 12px;
        color: #424242;
        text-align: left;
        list-style: none;
        background-color: #fff;
        background-clip: padding-box;
        padding: 0px;
        margin: 2px 0px 0px 0px;
    }
    .v-select[data-v-138dff1d] {
        position: relative;
        width: 100%;
        height: 30px;
        cursor: pointer;
    }
    .v-select.disabled[data-v-138dff1d] {
        cursor: not-allowed;
    }
    .v-select.disabled .v-select-toggle[data-v-138dff1d] {
        background-color: #f8f9fa;
        border-color: #f8f9fa;
        opacity: 0.65;
        cursor: not-allowed;
    }
    .v-select.disabled .v-select-toggle[data-v-138dff1d]:focus {
        outline: 0 !important;
    }
    .v-select-toggle[data-v-138dff1d] {
        display: flex;
        justify-content: space-between;
        user-select: none;
        padding: 0.375rem 0.75rem;
        color: #212529;
        background-color: #f8f9fa;
        border-color: #d3d9df;
        width: 100%;
        text-align: right;
        white-space: nowrap;
        border: 1px solid transparent;
        padding: 0.375rem 0.75rem;
        font-size: 12px;
        font-family: inherit, sans-serif;
        line-height: 1.5;
        border-radius: 0.25rem;
        transition: background-color, border-color, box-shadow, 0.15s ease-in-out;
        cursor: pointer;
    }
    .v-select-toggle[data-v-138dff1d]:hover {
        background-color: #e2e6ea;
        border-color: #dae0e5;
    }
    .arrow-down[data-v-138dff1d] {
        display: inline-block;
        width: 0;
        height: 0;
        margin-left: 0.255em;
        margin-top: 7px;
        vertical-align: 0.255em;
        content: "";
        border-top: 0.3em solid;
        border-right: 0.3em solid transparent;
        border-bottom: 0;
        border-left: 0.3em solid transparent;
    }
    .v-dropdown-container[data-v-138dff1d] {
        position: absolute;
        width: 100%;
        background: red;
        padding: 0.5rem 0;
        margin: 0.125rem 0 0;
        color: #212529;
        text-align: left;
        list-style: none;
        background-color: #fff;
        background-clip: padding-box;
        border-radius: 0.25rem;
        border: 1px solid rgba(0, 0, 0, 0.15);
        z-index: 1000;
    }
    .v-dropdown-item[data-v-138dff1d] {
        text-decoration: none;
        line-height: 25px;
        padding: 0.5rem 1.25rem;
        user-select: none;
    }
    .v-dropdown-item[data-v-138dff1d]:hover:not(.default-option) {
        background-color: #f8f9fa;
    }
    .v-dropdown-item.disabled[data-v-138dff1d] {
        color: #9a9b9b;
    }
    .v-dropdown-item.selected[data-v-138dff1d] {
        background-color: #007bff;
        color: #fff;
    }
    .v-dropdown-item.selected[data-v-138dff1d]:hover {
        background-color: #007bff;
        color: #fff;
    }
    .v-dropdown-item.disabled[data-v-138dff1d] {
        cursor: not-allowed;
    }
    .v-dropdown-item.disabled[data-v-138dff1d]:hover {
        background-color: #fff;
    }
    .v-bs-searchbox[data-v-138dff1d] {
        padding: 4px 8px;
    }
    .v-bs-searchbox .form-control[data-v-138dff1d] {
        display: block;
        width: 100%;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: 0.25rem;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }

    /*# sourceMappingURL=vue-bootstrap-select.vue.map */</style>
<?php include('footer.php') ?>
