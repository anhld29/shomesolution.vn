<section class="alert">
	<header class="panel-head">
		<h2 class="heading-1">Thông báo</h2>
	</header>
	<section class="panel-body">
		<?php echo $this->fcSystem['another_intro'] ?>
	</section>

</section>
