<link rel="stylesheet" type="text/css" href="template/mobile/css/fonts/font.css">
<link rel="stylesheet" type="text/css" href="template/mobile/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="template/mobile/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="template/mobile/css/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="template/mobile/css/owl.theme.default.css">
<link rel="stylesheet" href="template/mobile/css/demo.css?ver=3.3.0">
<link rel="stylesheet"  type="text/css"  href="template/mobile/css/swiper.min.css">
<link rel="stylesheet" type="text/css" href="template/mobile/css/style.css">
<link rel="stylesheet" type="text/css" href="template/mobile/css/responsive.css">
<script type="text/javascript" src="template/mobile/js/jquery.min.js"></script>
