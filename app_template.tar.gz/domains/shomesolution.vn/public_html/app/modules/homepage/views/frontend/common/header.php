<div id="header-general">

    <div id="vuanem-header"><!---->

        <div class="header-default">

            <div class="header-top">

                <div class="container">

                    <div id="header-top-left " class="header-top-left desktop">

                        <p>

                            <a href="<?php echo $this->fcSystem['link_link_tragop'] ?>">

                                <img class="nomal-image" src="template/frontend/images/khuyen-mai.png" alt="">

                                <img class="hover-image" src="template/frontend/images/ic-promotion-topbar-hover.png"

                                     alt="">

                                <?php echo $this->fcSystem['link_tragop'] ?>

                            </a>

                        </p>

                        <style xml="space">



                            @media (min-width: 1200px) {

                                .cms-home .product-listing.grid .item .product .left-content-info span.outstock {

                                    float: none;

                                    margin-left: 0;

                                    height: 52px;

                                    display: block;

                                    clear: both;

                                    width: 100%;

                                }



                                .product-listing .item .product .price-container .tra-gop-pr {

                                    padding-left: 10px;

                                    margin-left: 10px;

                                }

                            }



                            .banner-4image {

                                display: none !Important

                            }



                            .section-product .add-background-white .col-md-6 p {

                                margin-bottom: 0;

                            }



                            .vuanem-blog-list {

                                background-color: #fff;

                                padding: 40px 0 30px !important;

                            }



                            #vuanem-slide-image,

                            #testimonial {

                                display: none !important

                            }



                            .cms-tra-gop-online .page-wrapper .page-main .widget.block.block-static-block .products-grid .product-items:not(.owl-carousel) > .product-item {

                                width: 25%;

                            }



                            #vuanem-blog-list, #vuanem-flash-sales-new .loading-spin.container, .cdz-product-top, .item-caption p, .listing-block .image, .section-product .add-background-white, .section-tabs-brand .banner-image, .section-tabs-brand .section-brand, .slidemain-image .blog-wapper, .slider-image {

                                background: #fff !important;

                            }



                            #mattress-tab1 .item:after, #vuanem-blog-list:after, .cdz-product-top:after, .item-caption p:after, .listing-block .image:after, .loading-spin.container:after, .section-product .add-background-white:after, .section-tabs-brand .banner-image:after, .section-tabs-brand .section-brand:after, .slidemain-image .blog-wapper:after, .slider-image:after {

                                opacity: 0 !important

                            }



                            .loading-active-12 .slider-image {

                                height: auto;

                            }



                            body #vuanem-flash-sales-new {

                                margin: 0 !important;

                            }



                            #vuanem-flash-sales-new {

                            }



                            #footer-vuanem .container {

                                background: none

                            }



                            .product-listing.grid .item .product .product-link .product-cover {

                                padding-bottom: 110px;

                            }



                            .catalog-product-view .product-detail-product-info-detail .block-products-list .product-item {

                                width: 100% !important;

                            }



                            body.open-menu::before {

                                z-index: 6

                            }



                            #vuanem-header .main-menu .cdz-horizontal-menu > ul > li.level-top > .menu-link {

                                min-width: 52px;

                            }



                            .cms-home .column.main {

                                min-height: 0

                            }



                            #vuanem-header .hide-header .main-menu .cdz-horizontal-menu > ul > li.level-top:nth-child(5) > .menu-link .menu-icon {

                                display: none;

                            }



                            #vuanem-flash-sales-new .container.loading-spin {

                                min-height: inherit;

                                min-height: unset;

                            }



                            #vuanem-flash-sales-new {

                                min-height: inherit;

                                min-height: unset;

                            }





                            #vuanem-header .main-menu .cdz-horizontal-menu > ul > li.level-top:nth-child(5) > .menu-link .menu-icon {

                                display: block

                            }



                            #vuanem-header .main-menu .cdz-horizontal-menu > ul > li.level-top:nth-child(5) > .menu-link:before {

                                display: none !important

                            }



                            #vuanem-header .main-menu .cdz-horizontal-menu > ul > li.level-top > .menu-link:before {

                                height: 29px;

                                line-height: normal

                            }



                            body #product-detail-main-content .product-detail-first-block .product-detail .product.attibute.overview .size-thick {

                                width: 100%;

                                display: -webkit-box;

                                display: -ms-flexbox;

                                display: flex;

                                -webkit-box-orient: horizontal;

                                -webkit-box-direction: reverse;

                                -ms-flex-direction: row-reverse;

                                flex-direction: row-reverse;

                                border-bottom: 1px solid #ececec;

                            }



                            body #product-detail-main-content .product-detail-first-block .product-detail .product.attibute.overview .items-option:first-child {

                                padding-right: 0

                            }



                            .icon-images-pr .freeship-product img {

                                min-width: 40px;

                            }



                            .header-top-left a .nomal-image {

                                z-index: 1 !Important

                            }



                            .category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .product-type-key-attributes .attribute-wapprer, [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .item-product .product-type-key-attributes .attribute-wapprer {

                                padding-left: 20px !Important;

                                padding-right: 20 !important

                            }



                            [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .product-item-info {

                                width: 100%

                            }



                            #vuanem-product-filter .block.product-list .arrange-fill .view-detail {

                                display: block !important

                            }



                            #store-detail ul {

                                overflow-y: scroll;

                            }



                            .custom-sale-online {

                                display: none !important

                            }



                            #store-detail ul {

                                height: 160px;

                                max-height: 160px;

                            }



                            .block-detail-top > div:last-child {

                                width: 100%;

                            }



                            .product-item .freeship-product {

                                display: none !important

                            }



                            body #product-detail-main-content .product-detail-first-block .col-block-right {

                                background: #f0f2f4;

                                padding-top: 0;

                                padding-bottom: 0;

                            }



                            #product-detail-main-content .product-detail-first-block .col-block-right > div.detail-block-right-top {

                                padding-top: 15px;

                            }



                            #product-detail-main-content .product-detail-first-block .col-block-right > div {

                                background: #fff

                            }



                            .custom-sale-online svg {

                                width: 80%

                            }



                            .icon-images-pr {

                                z-index: 5

                            }



                            .tooltip-free {

                                display: none;

                            }



                            .freeship-product:hover .tooltip-free {

                                display: block;

                            }



                            .catalog-product-view #product-detail-product-info-detail .product-review-bottom .load-more {

                                height: 30px;

                            }



                            .catalog-product-view #product-detail-product-info-detail .product-review-bottom .load-more span {

                                position: absolute;

                                z-index: 11;

                            }



                            #product-detail-product-info-detail .product-item .active-freeship .freeship-product {

                                display: none

                            }



                            #product-detail-main-content .price-status.active-freeship .freeship-product {

                                color: #239B28;

                                display: none;

                                font-size: 18px;

                                font-weight: 600;

                            }



                            .product-detail .hotline {

                                display: none;

                            }



                            #product-detail-product-info-detail .product-item-details .price-box .normal-price .price {

                                text-decoration: line-through;

                                font-size: 14px;

                                color: #9a9a9a;

                            }



                            .header-top .container:before, .header-top .container:after {

                                display: none;

                            }



                            @media (min-width: 768px) {

                                #vuanem-header {

                                    height: 97px;

                                }

                            }



                            body .toggleOwl.mattress-tab-section {

                                padding-top: 15px;

                            }



                            body.cms-home.cms-index-index .page-wrapper .page-main .widget.block.block-static-block .cdz-block-title {

                                padding: 15px 20px 0;

                            }



                            @media (min-width: 768px) and (max-width: 1200px) {

                                body.category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content {

                                    width: 60% !important;

                                }



                                body.category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .tile-primary .left-content-info,

                                body[class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .tile-primary .left-content-info {

                                    border-right: none;

                                }

                            }



                            .banner2 > .row {

                                padding-bottom: 30px;

                                border-bottom: 1px solid #eaeaea;

                            }



                            body .information-product .section-title {

                                z-index: 1

                            }



                            #vuanem-product-filter .block.product-list .filter-list-box .filter-items h5,

                            #vuanem-product-filter .toolbar-sorter.sorter .sorter-desktop .sorter-label {

                                display: none !important

                            }



                            body.loading-active-12 .list-category-top a {

                                background-image: -webkit-gradient(linear, left top, left bottom, from(#fff), color-stop(72%, #fff), to(#c9d8ff));

                                background-image: linear-gradient(180deg, #fff, #fff 72%, #c9d8ff);

                            }



                            #searchsuite-autocomplete #product li:before {

                                border-bottom: 0 !important

                            }



                            .category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .product-type-key-attributes, [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .item-product .product-type-key-attributes {

                                padding: 15px 0 10px;

                            }



                            #vuanem-product-filter .block.product-list .arrange-fill .product-description .prod-desc-priceUI-1 {

                                margin-bottom: 10px;

                            }



                            body.category-nem #vuanem-product-filter .block.product-list .arrange-fill:hover {

                                box-shadow: none

                            }



                            body.category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content {

                                bottom: 0;

                                padding-top: 0;

                            }



                            body.category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product {

                                padding-bottom: 0

                            }



                            body:not([class*=category-nem-]) #vuanem-product-filter .block.product-list .arrange-fill, body:not([class*=category-nem]) #vuanem-product-filter .block.product-list .arrange-fill {

                                padding: 15px;

                                border-left: .5px solid rgba(41, 43, 183, .2);

                                margin: 0;

                                transition: all .25s;

                                -webkit-transition: all .25s;

                                -moz-transition: all .25s;

                                -o-transition: all .25s;

                                border-bottom: .5px solid rgba(41, 43, 183, .2);

                            }



                            body:not([class*=category-nem-]) #vuanem-product-filter .block.product-list .arrange-fill:nth-child(3n+1) {

                                border-left: none;

                            }



                            .category-nem #vuanem-product-filter .block.product-list .arrange-fill, [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill {

                                padding: 0 !important;

                                border-bottom: 0 !important;

                                border-left: 0 !important

                            }



                            .category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .tile-primary .left-content-info, [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .tile-primary .left-content-info {

                                padding-top: 10px;

                                padding-bottom: 0;

                            }



                            .catalogsearch-result-index .widget.block.block-static-block .cdz-best-seller-wrap .cdz-block-title {

                                padding-left: 15px;

                            }



                            @media (min-width: 767px) {

                                body #vuanem-header div#searchsuite-autocomplete .product {

                                    height: auto !important

                                }



                                body .product-item .active-tragop .tra-gop-pr {

                                    justify-content: center;

                                }



                                .main-menu .cdz-main-menu .groupmenu-drop-content.groupmenu-width-24.col-5 .row div.col-sm-4 {

                                    width: 20% !important

                                }



                                body:not([class*=category-nem-]) #vuanem-product-filter .block.product-list .arrange-fill .item-product, body:not([class*=category-nem]) #vuanem-product-filter .block.product-list .arrange-fill .item-product {

                                    padding-bottom: 110px;

                                }



                                body.category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product {

                                    padding: 5px 0px !important;

                                }



                                .cdz-product-top {

                                    height: auto !important

                                }



                                .products-grid .product-items:not(.owl-carousel) > .product-item .product-item-info {

                                    padding-bottom: 120px !important;

                                }



                                body.category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .tile-primary .custom-content {

                                    display: block !important;

                                    max-width: 200px

                                }



                                .category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .list-image-wrapper, [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .item-product .list-image-wrapper {

                                    margin: 15px 15px 12px 20px;

                                }



                                .category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .product-title, [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .product-title {

                                    height: auto !important

                                }



                                .category-nem #vuanem-product-filter .productprice.listview, [class*=category-nem-] #vuanem-product-filter .productprice.listview {

                                    height: auto

                                }



                                body #header-general {

                                    min-height: 90px;

                                }

                            }



                            .discount-percent {

                                z-index: 2

                            }



                            .slider-image > div {

                                z-index: 1

                            }



                            .cms-index-index .product-grid {

                                min-height: 400px

                            }



                            body #vuanem-product-filter .block.product-list .load-more a.learn-more {

                                z-index: 2

                            }



                            body #vuanem-product-filter .toolbar-sorter.sorter .sorter-desktop .sorter-options {

                                border-radius: 4px;

                            }



                            #vuanem-product-filter .productprice.listview {

                                height: 52px;

                            }



                            body:not([class*=category-nem]) #vuanem-product-filter .block.product-list .arrange-fill:last-child {

                                border-right: .5px solid rgba(41, 43, 183, .2);

                            }



                            .cms-page-view .page-main .block-static-block .cdz-block-title {

                                margin-bottom: 0;

                                padding-bottom: 30px;

                            }



                            .cms-page-view .page-wrapper .page-main .widget.block.block-static-block .products-grid .product-items:not(.owl-carousel) > .product-item:nth-child(4n+1) {

                                border-left: .5px solid rgba(41, 43, 183, .2);

                            }



                            .cms-page-view .page-wrapper .page-main .widget.block.block-static-block .products-grid .product-items:not(.owl-carousel) > .product-item:nth-child(4n) {

                                border-right: .5px solid rgba(41, 43, 183, .2);

                            }



                            .cms-page-view .flash-sale-items .product.data.items > .item.content {

                                padding-top: 0;

                            }



                            #vuanem-product-filter .block.filter .filter-options-item .open:nth-child(3) {

                                display: none;

                            }



                            @media (max-width: 767px) {

                                body .banner-4image .row.mobile {

                                    margin-top: 15px

                                }





                                body #HomeProductOne.section-product .cdz-block-titles h2:after {

                                    content: "Top nệm bán chạy";

                                    font-size: 20px;

                                }



                                body #HomeProductTwo.section-product .cdz-block-titles h2:after {

                                    content: "BST chăn ga mới nhất";

                                    font-size: 20px;

                                }



                                body #HomeProductThree.section-product .cdz-block-titles h2:after {

                                    content: "Phụ kiện giấc ngủ";

                                    font-size: 20px;

                                }



                                #vuanem-header .main-menu .cdz-horizontal-menu > ul > li.level-top:nth-child(6) > .menu-link:before {

                                    display: none

                                }



                                body #vuanem-header .cdz-main-menu .cdz-horizontal-menu li.level0 > a.menu-link {

                                    border-bottom: none;

                                    font-size: 20px !important;

                                }



                                .list-category-top {

                                    padding: 10px 5px 0;

                                }



                                .active-search-header.active-keysearch .header-bottom-mobile {

                                    position: relative

                                }



                                .active-keysearch .header-bottom-mobile {

                                    position: relative;

                                }



                                .active-search-header.active-keysearch .search-bottom {

                                    display: block

                                }



                                body .product-listing.grid .item .product .product-link .product-cover {

                                    padding-bottom: 180px;

                                }



                                body .product-item .product .old-price {

                                    line-height: 18px;

                                }



                                .product-listing.grid .item .product .left-content-info .price-container {

                                    height: 87px

                                }



                                body .store-location .label-store {

                                    white-space: nowrap;

                                }



                                body .header-bottom-mobile {

                                    margin-top: 0 !important

                                }



                                body.active-search-header .header-bottom-mobile {

                                    position: relative;

                                }



                                body.cms-tra-gop-online .page-wrapper .page-main .widget.block.block-static-block .products-grid .product-items:not(.owl-carousel) > .product-item {

                                    padding: 8px 3px !important;

                                }



                                .cms-tra-gop-online .page-main {

                                    position: relative;

                                    overflow: hidden

                                }



                                .catalog-category-view .category-view {

                                    display: none !important

                                }



                                body.add-padding-header #vuanem-header .header-top {

                                    z-index: 999

                                }



                                body .product-item .active-tragop .tra-gop-pr .appen {

                                    font-weight: 500

                                }



                                .category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .tile-primary .view-detail a, [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .tile-primary .view-detail a {

                                    color: #fff !important

                                }



                                .category-nem #vuanem-product-filter .block.product-list .arrange-fill, [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill {

                                    padding: 0 10px !important

                                }



                                [class*=category-nem-] #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content {

                                    width: 100% !important

                                }



                                #vuanem-product-filter .block.filter .filter-options-item .open:nth-child(3) {

                                    display: none;

                                }



                                body .product-item-details .price-box .normal-price {

                                    line-height: 25px;

                                }



                                body .left-content-info .price-freeship {

                                    padding: 0px 0 5px;

                                }



                                .price-freeship .discount-percent {

                                    right: 0px;

                                    margin-right: 5px;

                                }



                                #vuanem-product-filter .price-box.price-final_price {

                                    height: 55px;

                                }



                                body.category-nem #vuanem-product-filter .block.product-list .arrange-fill .view-detail {

                                    padding-top: 5px;

                                    margin-top: 0;

                                }



                                body .block-products-list .products-grid .product-items .product-item .product-item-info .product-item-details .view-detail a {

                                    background: #4143DB;

                                }



                                body .page-wrapper .page-main .widget.block.block-static-block .products-grid .product-items:not(.owl-carousel) > .product-item {

                                    padding: 8px 1px !important;

                                }



                                #product-detail-main-content .product-detail-first-block .product-detail .old-price {

                                    margin-left: 0;

                                }



                                body .tooltip-free {

                                    width: 100px;

                                }



                                .product-detail .price-freeship {

                                    display: block

                                }



                                .product-image-single .icon-play {

                                    display: none

                                }



                                .cms-home .cdz-product-top {

                                    height: auto !important

                                }



                                .banner-landing {

                                    margin: -35px -23px 0 !important;

                                    max-width: unset !important;

                                    flex: auto !important;

                                }



                                .banner2 img {

                                    margin-bottom: 15px;

                                }



                                .category-nem-nhap-khau-dat-hang-online.catalog-category-view .wrapper-breadcrums .item {

                                    display: none !important

                                }



                                #vuanem-product-filter .toolbar-sorter.sorter .filter-mobile span {

                                    display: block !important

                                }



                                body.active-search-header .header-bottom-mobile .search-bottom {

                                    height: calc(100vh - 105px);

                                }



                                .loading-active-12 .header-homepage-slider .listing-block .image {

                                    height: auto;

                                }



                                body.category-nem #vuanem-product-filter .block.product-list .arrange-fill .item-product .tile-content .tile-primary .left-content-info {

                                    padding-right: 0

                                }



                                body .vuanem-homepage #vuanem-blog-list {

                                    padding: 0;

                                }



                                body.open-filter #vuanem-product-filter {

                                    z-index: unset;

                                    z-index: inherit;

                                }



                                .section-nem-item.mobile.tabs-items-brand {

                                    margin-top: 10px;

                                }



                                .loading-active-12 .slideshow-container.not-display-on-mobile {

                                    min-height: auto;

                                    min-height: inherit;

                                    min-height: unset

                                }



                                .image-banner.mobile a {

                                    position: relative;

                                    z-index: 1

                                }



                                body.catalog-product-view #header-general {

                                    padding-top: 0px !important;

                                }



                                body #header-general {

                                    padding-top: 52px !important;

                                }



                                body:not([class*=category-nem]) #vuanem-product-filter .block.product-list .arrange-fill {

                                    padding: 10px !important;

                                    border-left: 0.5px solid rgba(41, 43, 183, 0.2);

                                    margin: 0 !important;

                                    transition: all .25s;

                                    -webkit-transition: all .25s;

                                    -moz-transition: all .25s;

                                    -o-transition: all .25s;

                                    border-bottom: 0.5px solid rgba(41, 43, 183, 0.2);

                                }



                                body #vuanem-product-filter .block.filter .filter-items {

                                    height: auto !important

                                }



                                body #vuanem-product-filter .toolbar-sorter.sorter {

                                    padding: 10px 0

                                }



                                body #vuanem-product-filter .block.product-list .filter-list-box {

                                    padding-top: 10px;

                                }



                                body #vuanem-product-filter .block.product-list .filter-list-box .filter-items h5 {

                                    display: none !important

                                }



                                body #vuanem-product-filter .block.product-list .arrange-fill .productprice .price-box .old-price {

                                    padding-bottom: 0;

                                }



                                body #vuanem-product-filter .block.product-list {

                                    margin-top: 0;

                                }



                                body #vuanem-product-filter .block.product-list .arrange-fill .view-detail {

                                    height: auto;

                                    border: 0;

                                }



                                body #vuanem-product-filter .block.product-list .arrange-fill .view-detail a {

                                    display: block;



                                    display: block;

                                    color: #fff !important;

                                    background-color: #4143db !important;

                                    border-radius: 4px;

                                    height: 42px;

                                    line-height: 42px;

                                    font-size: 18px;

                                }



                                body:not([class*=category-nem]) #vuanem-product-filter .block.product-list .arrange-fill .tile-content {

                                    padding-top: 5px;

                                }



                                body:not([class*=category-nem]) #vuanem-product-filter .block.product-list .arrange-fill .product-title {

                                    margin-top: 5px;

                                    height: 48px;

                                    line-height: 22px;

                                }



                                body:not([class*=category-nem]) #vuanem-product-filter .block.product-list .productprice.listview {

                                    height: 55px;

                                }



                                body:not([class*=category-nem]) #vuanem-product-filter .block.product-list .arrange-fill {

                                    margin-bottom: 0

                                }



                                body #vuanem-flash-sales-new .container .hot-deal .VueCarousel .VueCarousel-wrapper {

                                    padding: 10px 0;

                                }



                                #block-banner-top img {

                                    width: 100%;

                                }

                            }



                            @media (max-width: 374px) {

                                body #vuanem-product-filter .block.product-list .arrange-fill .product-title {

                                    margin-bottom: 0

                                }



                                body .price-freeship .discount-percent {

                                    right: 10px;

                                }

                            }



                            --></style>

                    </div>

                    <div class="information-website">

                        <div class="items-link login desktop">



                            <i class="icons user"></i>





                            <?php if (isset($this->FT_auth['id'])) { ?>

                                <a href="information.html" class="content">Tài khoản của tôi</a>

                            <?php } else { ?>

                                <a href="login.html" class="content">Đăng nhập</a>

                            <?php } ?>





                        </div>

                        <div class="information-websites mobile">

                            <div class="items-link phone"><p class="title">Mua hàng, gọi ngay</p> <a

                                        href="tel:<?php echo $this->fcSystem['contact_hotline'] ?>"

                                        class="content"><?php echo $this->fcSystem['contact_hotline'] ?></a></div>

                        </div>

                        <div class="store-location mobile">

                            <a href="stores.html"><img

                                        src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMC44MDUiIHZpZXdCb3g9IjAgMCAzMiAzMC44MDUiPgogIDxnIGlkPSJpY29uX2xvY2F0aW9uIiBkYXRhLW5hbWU9Imljb24gbG9jYXRpb24iIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDE4IC01MC4xOTUpIj4KICAgIDxnIGlkPSJFbGxpcHNlXzkxIiBkYXRhLW5hbWU9IkVsbGlwc2UgOTEiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwMjUgNzEpIiBmaWxsPSIjZmZmIiBzdHJva2U9IiMyOTJiYjciIHN0cm9rZS13aWR0aD0iMSIgb3BhY2l0eT0iMC41Ij4KICAgICAgPGVsbGlwc2UgY3g9IjkiIGN5PSIzLjUiIHJ4PSI5IiByeT0iMy41IiBzdHJva2U9Im5vbmUiLz4KICAgICAgPGVsbGlwc2UgY3g9IjkiIGN5PSIzLjUiIHJ4PSI4LjUiIHJ5PSIzIiBmaWxsPSJub25lIi8+CiAgICA8L2c+CiAgICA8ZyBpZD0iRWxsaXBzZV85MiIgZGF0YS1uYW1lPSJFbGxpcHNlIDkyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDE4IDY4KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMjkyYmI3IiBzdHJva2Utd2lkdGg9IjEiIG9wYWNpdHk9IjAuNSI+CiAgICAgIDxlbGxpcHNlIGN4PSIxNiIgY3k9IjYuNSIgcng9IjE2IiByeT0iNi41IiBzdHJva2U9Im5vbmUiLz4KICAgICAgPGVsbGlwc2UgY3g9IjE2IiBjeT0iNi41IiByeD0iMTUuNSIgcnk9IjYiIGZpbGw9Im5vbmUiLz4KICAgIDwvZz4KICAgIDxwYXRoIGlkPSJQYXRoXzI3IiBkYXRhLW5hbWU9IlBhdGggMjciIGQ9Ik02Ni42MDYsMGE5LjQ1NSw5LjQ1NSwwLDAsMC05LjQ1NSw5LjQ1NWMwLDcuNTcxLDguNTQ3LDE0LjU4Myw4LjU0NywxNC41ODNhMS41LDEuNSwwLDAsMCwxLjgxNiwwczguNTQ3LTcuMDEyLDguNTQ3LTE0LjU4M0E5LjQ1NSw5LjQ1NSwwLDAsMCw2Ni42MDYsMFptMCwxNC4yMTJhNC43NTcsNC43NTcsMCwxLDEsNC43NTctNC43NTdBNC43NjIsNC43NjIsMCwwLDEsNjYuNjA2LDE0LjIxMloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDk2Ny42NDUgNTAuMTk1KSIgZmlsbD0iIzI5MmJiNyIvPgogIDwvZz4KPC9zdmc+Cg=="

                                        class="desktop">

                                <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1Mi43ODMiIGhlaWdodD0iMzYuNTYxIiB2aWV3Qm94PSIwIDAgNTIuNzgzIDM2LjU2MSI+CiAgPGcgaWQ9ImljLWxvY2F0aW9uIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjIwLjg0NSAtMzIzLjUyNykiPgogICAgPGcgaWQ9Ikdyb3VwXzczNCIgZGF0YS1uYW1lPSJHcm91cCA3MzQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIzMi40OTMgMzQ0LjIwNikiPgogICAgICA8cGF0aCBpZD0iUGF0aF8yNjkiIGRhdGEtbmFtZT0iUGF0aCAyNjkiIGQ9Ik0yNTAuODE1LDM1Ni45OTRjLTcuNDUsMC0xNC45OTItMS40MzItMTQuOTkyLTQuMTY5czcuNTQyLTQuMTcsMTQuOTkyLTQuMTcsMTQuOTkyLDEuNDMzLDE0Ljk5Miw0LjE3UzI1OC4yNjYsMzU2Ljk5NCwyNTAuODE1LDM1Ni45OTRabTAtNy4xNDdhNDMuMjI3LDQzLjIyNywwLDAsMC05Ljk3MiwxLjAyNiwxMS40MzcsMTEuNDM3LDAsMCwwLTIuODkzLDEuMDYyYy0uNTM1LjMxNS0uODI5LjYzMS0uODI5Ljg5LDAsLjUxLDEuMTUxLDEuMzEyLDMuNzIxLDEuOTUyYTQ4Ljk2Miw0OC45NjIsMCwwLDAsMTkuOTQ0LDAsMTEuNDQ4LDExLjQ0OCwwLDAsMCwyLjg5My0xLjA2MmMuNTM1LS4zMTQuODI5LS42MzEuODI5LS44OSwwLS41MS0xLjE1MS0xLjMxMi0zLjcyMi0xLjk1MkE0My4yMjMsNDMuMjIzLDAsMCwwLDI1MC44MTUsMzQ5Ljg0N1oiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMzUuODIzIC0zNDguNjU1KSIgZmlsbD0iIzJkMmU3ZiIvPgogICAgPC9nPgogICAgPGcgaWQ9Ikdyb3VwXzczNSIgZGF0YS1uYW1lPSJHcm91cCA3MzUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIyNi40NyAzNDAuNzAyKSIgb3BhY2l0eT0iMC4yIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfMjcwIiBkYXRhLW5hbWU9IlBhdGggMjcwIiBkPSJNMjQ5LjEyMSwzNTkuNzQ1YTQ0LjYsNDQuNiwwLDAsMS0xNC4zNTItMi4xMTJjLTQuMDM5LTEuNDMtNi4yNjMtMy40MDYtNi4yNjMtNS41NjJzMi4yMjUtNC4xMzIsNi4yNjMtNS41NjNhNDkuODQ4LDQ5Ljg0OCwwLDAsMSwyOC43LDBjNC4wMzksMS40MzEsNi4yNjMsMy40MDYsNi4yNjMsNS41NjNzLTIuMjI1LDQuMTMyLTYuMjYzLDUuNTYyQTQ0LjYsNDQuNiwwLDAsMSwyNDkuMTIxLDM1OS43NDVabTAtMTQuMTU3YTQzLjI1LDQzLjI1LDAsMCwwLTEzLjkwNiwyLjAzNWMtMy40NTksMS4yMjUtNS40NDIsMi44NDctNS40NDIsNC40NDhzMS45ODMsMy4yMjMsNS40NDIsNC40NDhhNDguNTQ1LDQ4LjU0NSwwLDAsMCwyNy44MTIsMGMzLjQ1OC0xLjIyNSw1LjQ0Mi0yLjg0Nyw1LjQ0Mi00LjQ0OHMtMS45ODQtMy4yMjMtNS40NDItNC40NDhBNDMuMjU4LDQzLjI1OCwwLDAsMCwyNDkuMTIxLDM0NS41ODhaIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjI4LjUwNSAtMzQ0LjM5NykiIGZpbGw9IiMyZDJlN2YiIG9wYWNpdHk9IjAuMjY2Ii8+CiAgICA8L2c+CiAgICA8ZyBpZD0iR3JvdXBfNzM2IiBkYXRhLW5hbWU9Ikdyb3VwIDczNiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjIwLjg0NSAzMzYuNjY1KSIgb3BhY2l0eT0iMC4yIj4KICAgICAgPHBhdGggaWQ9IlBhdGhfMjcxIiBkYXRhLW5hbWU9IlBhdGggMjcxIiBkPSJNMjQ4LjA2MSwzNjQuNzI2YTQ4LjMyNiw0OC4zMjYsMCwwLDEtMTguNDQ4LTMuMjc4Yy01LjEyMy0yLjE5My03Ljk0NC01LjE4OC03Ljk0NC04LjQzNHMyLjgyMi02LjI0Miw3Ljk0NC04LjQzNGE1My41NjIsNTMuNTYyLDAsMCwxLDM2LjksMGM1LjEyMiwyLjE5Miw3Ljk0Myw1LjE4OCw3Ljk0Myw4LjQzNHMtMi44MjIsNi4yNDEtNy45NDMsOC40MzRBNDguMzMzLDQ4LjMzMywwLDAsMSwyNDguMDYxLDM2NC43MjZabTAtMjIuMDU4YTQ3LjE1Nyw0Ny4xNTcsMCwwLDAtMTcuOTkyLDMuMTg0Yy00LjU0NCwxLjk0NS03LjE1LDQuNTU2LTcuMTUsNy4xNjNzMi42MDYsNS4yMTgsNy4xNSw3LjE2M2E1Mi40NDIsNTIuNDQyLDAsMCwwLDM1Ljk4MywwYzQuNTQ0LTEuOTQ1LDcuMTUtNC41NTYsNy4xNS03LjE2M3MtMi42MDYtNS4yMTktNy4xNS03LjE2M0E0Ny4xNTMsNDcuMTUzLDAsMCwwLDI0OC4wNjEsMzQyLjY2OFoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMjEuNjY5IC0zNDEuMzAzKSIgZmlsbD0iIzJkMmU3ZiIgb3BhY2l0eT0iMC4wNiIvPgogICAgPC9nPgogICAgPGcgaWQ9Ikdyb3VwXzczNyIgZGF0YS1uYW1lPSJHcm91cCA3MzciIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIzNy40NzUgMzIzLjUyNykiPgogICAgICA8cGF0aCBpZD0iUGF0aF8yNzIiIGRhdGEtbmFtZT0iUGF0aCAyNzIiIGQ9Ik0yNTAuMzI0LDMyMy41MjdhOS45NDksOS45NDksMCwwLDAtOS45NDksOS45NDljMCw3Ljk2Niw4Ljk5MywxNS4zNDUsOC45OTMsMTUuMzQ1YTEuNTc2LDEuNTc2LDAsMCwwLDEuOTExLDBzOC45OTQtNy4zNzksOC45OTQtMTUuMzQ1QTkuOTQ5LDkuOTQ5LDAsMCwwLDI1MC4zMjQsMzIzLjUyN1ptMCwxNC45NTRhNS4wMDUsNS4wMDUsMCwxLDEsNS4wMDYtNS4wMDVBNS4wMTEsNS4wMTEsMCwwLDEsMjUwLjMyNCwzMzguNDgxWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI0MC4zNzUgLTMyMy41MjcpIiBmaWxsPSIjMmQyZTdmIi8+CiAgICA8L2c+CiAgICA8Y2lyY2xlIGlkPSJFbGxpcHNlXzIzIiBkYXRhLW5hbWU9IkVsbGlwc2UgMjMiIGN4PSI1LjAzNCIgY3k9IjUuMDM0IiByPSI1LjAzNCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjQyLjQyMSAzMjguNDYyKSIgZmlsbD0iI2ZmZiIvPgogIDwvZz4KPC9zdmc+Cg=="

                                     class="mobile">

                                <div class="label-store">Hệ thống<br>cửa hàng</div>

                            </a>

                        </div>

                        <div class="mini-cart">

                            <div id="mini-cart">

                                <span class="number-items"><?php echo $this->cart->total_items() ?></span>

                                <div class="cart-icon">Giỏ Hàng</div>

                            </div>



                            <div class="overlay"></div>



                            <?php echo $this->load->view('homepage/frontend/core/html_cart') ?>

                        </div>

                    </div>



                </div>

            </div>

            <?php $main_nav = navigation(array('keyword' => 'main', 'output' => 'array'), $this->fc_lang); ?>



            <?php if (svl_ismobile() == 'is mobile') { ?>

                <style>

                    #vuanem-header .body-no-result .icon-no-result {

                        background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4NCIgaGVpZ2h0PSI4NCI+PHBhdGggZmlsbD0iI2RkZCIgZD0iTTgxLjA3IDI5LjIwMWExLjkzNCAxLjkzNCAwIDAxLTEuOTMyIDEuOTMySDQuODY1QTEuOTM0IDEuOTM0IDAgMDEyLjkzMyAyOS4ydi0zLjA5NGMwLTEuMDY1Ljg2Ny0xLjkzMiAxLjkzMi0xLjkzMkg1OS45NGExLjIxNiAxLjIxNiAwIDAwMC0yLjQzMUgxNS42OFY4LjY2bDQuMDM0IDIuMDE3YTYuNDEgNi40MSAwIDAwMi44NTMuNjc0aDExLjMzYy45ODYgMCAxLjk3My0uMjMzIDIuODU0LS42NzRsNC4wMzQtMi4wMTd2MTAuNzMzYTEuMjE2IDEuMjE2IDAgMDAyLjQzMiAwVjguNjZsNC4wMzUgMi4wMTdhNi40MSA2LjQxIDAgMDAyLjg1My42NzRoMTEuMzNjLjk4NiAwIDEuOTczLS4yMzMgMi44NTMtLjY3NGw0LjAzNS0yLjAxN3YxMy4wODNoLTMuNzhhMS4yMTYgMS4yMTYgMCAwMDAgMi40MzJoMTQuNTk1YzEuMDY1IDAgMS45MzEuODY3IDEuOTMxIDEuOTMxem0tMS41NzQgMzEuNTI0YTEuOTM0IDEuOTM0IDAgMDEtMS45MzIgMS45MzJINTkuMzk3YzguMDg3LTQuNTc2IDE0LjQzMi0xNS4yNjggMTYuNjU4LTI5LjA5M2gzLjA4M2MuMTIgMCAuMjQtLjAwNi4zNTgtLjAxNnptLTEuNzMxIDkuNDQyYzAgLjE5Ny0uMTYuMzU4LS4zNTguMzU4SDQ5LjMwM2MtMi4yNzMgMC00LjU2MS0uMTktNi44MDItLjU2M2wtMi40ODgtLjQxNWE0My45MzcgNDMuOTM3IDAgMDAtNy4yMDItLjU5Nkg2LjU5NmEuMzU4LjM1OCAwIDAxLS4zNTgtLjM1OHYtMy41MWMuMDY2LjAwMy4xMzMuMDA1LjIuMDA1SDE3LjYxYTEuMjE2IDEuMjE2IDAgMTAwLTIuNDMxSDYuNDM4YTEuOTM0IDEuOTM0IDAgMDEtMS45MzEtMS45MzJWMzMuNTQ4Yy4xMTguMDEuMjM3LjAxNi4zNTguMDE2aDY0LjA1M2MtMi44ODMgNC4zNjItOC4yODUgOC4yOTUtMTUuNDY1IDExLjIxMi04LjUyMSAzLjQ2Mi0xOC43OTMgNS4yOTItMjkuNzA1IDUuMjkyYTEuMjE2IDEuMjE2IDAgMDAwIDIuNDMxYzExLjIyMyAwIDIxLjgxMS0xLjg5MSAzMC42Mi01LjQ3IDguMzMxLTMuMzg1IDE0LjQ2OC04LjE0NiAxNy4zODgtMTMuNDY1aDEuODM0Yy0xLjM2NyA4LjEzLTQuMzI3IDE1LjQ0OC04LjM4OSAyMC42OTYtNC4yNTIgNS40OTMtOS4zMzYgOC4zOTctMTQuNzAyIDguMzk3SDIyLjAxN2ExLjIxNiAxLjIxNiAwIDAwMCAyLjQzMWg1NS41NDdjLjA2OCAwIC4xMzQtLjAwMi4yLS4wMDV6bS0xLjU3NCAxMC45aC0zLjg2M3YtMy44MmMwLS42Ny0uNTQ0LTEuMjE1LTEuMjE1LTEuMjE1SDEyLjg5Yy0uNjcyIDAtMS4yMTYuNTQ0LTEuMjE2IDEuMjE2djMuODJINy44MTF2LTkuNjg1aDI1YzIuMjczIDAgNC41NjEuMTg5IDYuODAzLjU2M2wyLjQ4Ny40MTRjMi4zNzMuMzk2IDQuNzk2LjU5NiA3LjIwMi41OTZINzYuMTl6TTcuNjU0IDguMDFjMC0yLjggMi4yNzgtNS4wNzggNS4wNzgtNS4wNzhINzEuMjdjMi44IDAgNS4wNzggMi4yNzggNS4wNzggNS4wNzh2MTMuNzMzaC01LjU5M1Y4LjA4NWMwLS43MjUtLjM2OC0xLjM4NS0uOTg1LTEuNzY2YTIuMDYyIDIuMDYyIDAgMDAtMi4wMi0uMDkxTDYzLjIgOC41MDJhMy45NjYgMy45NjYgMCAwMS0xLjc2NS40MTdoLTExLjMzYTMuOTcgMy45NyAwIDAxLTEuNzY2LS40MTdMNDMuNzkgNi4yMjhhMi4wNiAyLjA2IDAgMDAtMS43ODktLjAzMiAyLjA2IDIuMDYgMCAwMC0xLjc4OS4wMzJsLTQuNTQ5IDIuMjc0YTMuOTY2IDMuOTY2IDAgMDEtMS43NjUuNDE3SDIyLjU2N2EzLjk3IDMuOTcgMCAwMS0xLjc2Ni0uNDE3bC00LjU0OC0yLjI3NGEyLjA2MyAyLjA2MyAwIDAwLTIuMDIuMDkgMi4wNjMgMi4wNjMgMCAwMC0uOTg1IDEuNzY3djEzLjY1OEg3LjY1NHpNNzguNzggMjEuNzQzVjguMDFjMC00LjE0LTMuMzY5LTcuNTEtNy41MS03LjUxSDEyLjczMmMtNC4xNCAwLTcuNTEgMy4zNy03LjUxIDcuNTF2MTMuNzMzaC0uMzU3YTQuMzY4IDQuMzY4IDAgMDAtNC4zNjMgNC4zNjN2My4wOTVjMCAxLjM0Ni42MTIgMi41NSAxLjU3MyAzLjM1MnYyOC4xNzJjMCAxLjQxOC42OCAyLjY4IDEuNzMxIDMuNDc3djQuMzkxQTIuNzkgMi43OSAwIDAwNS4zOCA3MS4xdjEwLjM5NmMwIDEuMTA1Ljg5OCAyLjAwMyAyLjAwMiAyLjAwM2g0LjcyMWEyLjAwNSAyLjAwNSAwIDAwMi4wMDMtMi4wMDN2LTMuMDMzaDU1Ljc5djMuMDMzYzAgMS4xMDUuOSAyLjAwMyAyLjAwNCAyLjAwM2g0LjcyYTIuMDA1IDIuMDA1IDAgMDAyLjAwMy0yLjAwM3YtOC44MjNhMi43OSAyLjc5IDAgMDAxLjU3NC0yLjUwNnYtNS45NjVhNC4zNTggNC4zNTggMCAwMDEuNzMtMy40NzdWMzIuNTUzYTQuMzU1IDQuMzU1IDAgMDAxLjU3NC0zLjM1MnYtMy4wOTRhNC4zNjkgNC4zNjkgMCAwMC00LjM2My00LjM2NHoiLz48L3N2Zz4=) no-repeat;

                        background-size: cover;

                        width: 85px;

                        height: 85px;

                        margin: 0 auto;

                    }

                    #vuanem-header .body-no-result .description-no-result {

                        text-align: center;

                        color: #505050;

                        font-size: 18px;

                        line-height: 26px;

                        margin-top: 30px;

                    }

                </style>

                <div class="header-bottom-mobile">

                    <div class="container">

                        <div class="sidebar-mobile">

                            <div class="icons-menu">

                                <div class="line"></div>

                                <div class="line"></div>

                                <div class="line"></div>

                            </div>

                        </div>



                        <div class="right-block">

                            <div class="logo-header">

                                <a href="<?php echo base_url() ?>"><img

                                            src="<?php echo $this->fcSystem['homepage_logo'] ?>"

                                            alt="<?php echo $this->fcSystem['homepage_company'] ?>" width="60"

                                            class="main-logo"></a>

                            </div>

                            <div class="search-bar-mobile">

                                <div class="search-form-container step1">

                                    <div class="block-icon-seach"><i class="fa fa-search"></i></div>

                                    <form id="search_mini_form" action="tim-kiem.html" method="get"

                                          class="form minisearch has-cat">

                                        <div class="field search"><input id="search" value="" type="text" name="keyword"

                                                                         placeholder="Tìm kiếm" autocomplete="off"

                                                                         class="input-text"></div>

                                        <div class="actions">

                                            <button type="submit" title="Tìm kiếm"

                                                    class="action search primary search-icon-mobile"></button>

                                        </div>

                                    </form>

                                    <div class="search-bottom">

                                        <div class="search-result">

                                            <div class="v-autocomplete">



                                            </div>

                                        </div>

                                        <?php /*<div class="search-hind">

                                            <div class="search-hind 1"><label>Từ khóa gợi ý</label>

                                                <div class="result-hind">

                                                    <div class="item"><a

                                                                href="https://vuanem.com/khuyen-mai/mung-tan-gia/">Nệm

                                                            chung cư </a></div>

                                                    <div class="item"><a

                                                                href="https://vuanem.com/khuyen-mai/mua-1-tang-1/">Mua 1

                                                            Tặng 1</a></div>

                                                    <div class="item"><a

                                                                href="https://vuanem.com/nem/foam?src=mega-menu">Nệm

                                                            foam </a></div>

                                                    <div class="item"><a

                                                                href="https://vuanem.com/khuyen-mai/giam-5-trieu/">Giảm

                                                            5 triệu</a></div>

                                                    <div class="item"><a

                                                                href="https://vuanem.com/chinh-sach-van-chuyen-giao-nhan">Freeship</a>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>*/?>

                                    </div>



                                </div>

                            </div>

                        </div>

                    </div>

                </div>

                <div id="header-bottom" class="header-bottom ">

                    <div class="container">

                        <div class="sidebar-mobile" id="sidebar-mobile-close"><span>Đóng</span></div>

                        <div class="main-menu">

                            <div class="widget block block-static-block">

                                <div class="cdz-main-menu">

                                    <div class="cdz-menu cdz-horizontal-menu cdz-normal">

                                        <ul class="groupmenu">



                                            <?php if (isset($main_nav) && is_array($main_nav) && count($main_nav)) { ?>

                                                <?php $i = 0;

                                                foreach ($main_nav



                                                         as $key => $val) {

                                                    $i++; ?>



                                                    <li class="item level0 position-static level-top parent">

                                                        <a class="menu-link" href="<?php echo $val['link']; ?>"><i

                                                                    class="menu-icon img-icon"><img

                                                                        src="<?php echo $val['image']; ?>"></i>

                                                            <span><?php echo $val['title']; ?></span></a>



                                                        <?php /*<ul class="groupmenu-drop">

                                                <li class="item level1 has-submenu  text-content">

                                                    <div class="has-submenu  groupmenu-drop-content groupmenu-width-24"

                                                        <div class="row">

                                                            <div class="col-sm-4">

                                                                <p

                                                                        class="groupdrop-title font-bold-stag">

                                                                    Phụ kiện giấc ngủ<span

                                                                            class="dropdown-icon"><i

                                                                                class="fa fa-angle-right"></i></span>

                                                                </p>

                                                                <ul class="groupdrop-link size">

                                                                    <li class="item"><a title="Mua gối"

                                                                                        href="https://vuanem.com/phu-kien/goi?src=mega-menu">Gối</a>

                                                                    </li>

                                                                    <li class="item"><a

                                                                                title="Gối tựa trang trí"

                                                                                href="https://vuanem.com/phu-kien/goi-tua-trang-tri?src=mega-menu">Gối

                                                                            Tựa Trang Trí</a>

                                                                    </li>

                                                                    <li class="item"><a

                                                                                title="Tấm bảo vệ nệm, đệm"

                                                                                href="https://vuanem.com/phu-kien/tam-bao-ve-nem?src=mega-menu">Tấm

                                                                            Bảo Vệ Nệm</a></li>

                                                                    <li class="item"><a

                                                                                title="Tấm tăng tiện ích"

                                                                                href="https://vuanem.com/phu-kien/tam-tang-tien-ich-nem?src=mega-menu">Tấm

                                                                            Tăng Tiện Ích

                                                                            Nệm</a></li>

                                                                    <li class="item"><a

                                                                                title="Ruột chăn, mền"

                                                                                href="https://vuanem.com/phu-kien/ruot-chan?src=mega-menu">Ruột

                                                                            Chăn</a></li>

                                                                    <li class="item"><a

                                                                                title="Phụ kiện khác"

                                                                                href="https://vuanem.com/phu-kien/phu-kien-khac?src=mega-menu">Phụ

                                                                            kiện khác</a></li>

                                                                </ul>

                                                            </div>

                                                            <div class="col-sm-4">

                                                                <p

                                                                        class="groupdrop-title font-bold-stag">

                                                                    Kích thước<span class="dropdown-icon"><i

                                                                                class="fa fa-angle-right"></i></span>

                                                                </p>

                                                                <ul class="groupdrop-link">

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;size=332">45

                                                                            x 65cm</a></li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;size=334">50

                                                                            x 70cm</a></li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;size=338">60

                                                                            x 60cm</a></li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;size=30">160

                                                                            x 200cm</a></li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;size=31">180

                                                                            x 200cm</a></li>

                                                                </ul>

                                                            </div>

                                                            <div class="col-sm-4">

                                                                <p

                                                                        class="groupdrop-title font-bold-stag">

                                                                    Giá tiền<span class="dropdown-icon"><i

                                                                                class="fa fa-angle-right"></i></span>

                                                                </p>

                                                                <ul class="groupdrop-link">

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;price=-1000000">Dưới

                                                                            1 triệu</a></li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;price=1000000-2000000">Từ

                                                                            1 - 2 triệu</a></li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;price=3000000-">Trên

                                                                            3 triệu</a></li>

                                                                </ul>

                                                            </div>

                                                            <div class="col-sm-4">

                                                                <p

                                                                        class="groupdrop-title font-bold-stag">

                                                                    Thương hiệu<span

                                                                            class="dropdown-icon"><i

                                                                                class="fa fa-angle-right"></i></span>

                                                                </p>

                                                                <ul class="groupdrop-link">

                                                                    <li class="item hot-item">

                                                                        <a href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;product_brand=300"><span

                                                                                    style="color: #ff0000;"><span

                                                                                        style="color: #ff0000;">Aeroflow</span></span></a>

                                                                    </li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;product_brand=293">Amando</a>

                                                                    </li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;product_brand=312">Arena</a>

                                                                    </li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;product_brand=313">Doona</a>

                                                                    </li>

                                                                    <li class="item"><a

                                                                                href="https://vuanem.com/phu-kien?brandid=0&amp;catid=20&amp;product_brand=295">Hanvico</a>

                                                                    </li>

                                                                </ul>

                                                            </div>

                                                            <div class="col-sm-8">

                                                                <p><img

                                                                            src="https://media.vuanem.com/wysiwyg/homepage/medallion-deluxe-comforter-set-with-sheet-pillowcase-mattress-pad-pillow-grey-bedding-teal-and.jpg"

                                                                            width="710" height="710"></p>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </li>

                                            </ul>*/ ?>

                                                    </li>

                                                <?php } ?>

                                            <?php } ?>



                                            <?php /* <li class="item level0  level-top">



                                                <a class="menu-link"

                                                   href="<?php echo $this->fcSystem['menu_link_tl'] ?>">

                                                    <i class="menu-icon img-icon"><img

                                                                src="<?php echo $this->fcSystem['menu_icon_tl'] ?>"></i>

                                                    <span><span style="color:red"><?php echo $this->fcSystem['menu_title_tl'] ?></span></span>

                                                </a>

                                            </li>

                                            <li class="item level0 mobile color-red level-top">

                                                <a class="menu-link"

                                                   href="<?php echo $this->fcSystem['menu_link_tkm'] ?>">

                                                    <i class="menu-icon img-icon"><img

                                                                src="<?php echo $this->fcSystem['menu_icon_km'] ?>"

                                                                alt="<?php echo $this->fcSystem['menu_title_km'] ?>"></i><span><?php echo $this->fcSystem['menu_title_km'] ?></span>

                                                </a>

                                            </li>*/ ?>

                                        </ul>

                                    </div>

                                    <nav class="navigation" data-action="navigation">

                                        <ul data-mage-init="{&quot;menu&quot;:{&quot;responsive&quot;:true, &quot;expanded&quot;:true, &quot;position&quot;:{&quot;my&quot;:&quot;left top&quot;,&quot;at&quot;:&quot;left bottom&quot;}}}">

                                        </ul>

                                    </nav>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            <?php } else { ?>

                <style>

                    #vuanem-header .body-no-result {

                        border-radius: 4px;

                        border: 1px solid #20315c;

                    }

                    #vuanem-header .body-no-result {

                        text-align: center;

                        padding: 20px 0 15px;

                        position: absolute;

                        top: 0;

                        left: 0;

                        width: 100%;

                        min-width: 320px;

                        background: #fff;

                        z-index: 12;

                        border-bottom: 1px solid #20315c;

                    }

                    #vuanem-header .body-no-result .icon-no-result {

                        background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4NCIgaGVpZ2h0PSI4NCI+PHBhdGggZmlsbD0iI2RkZCIgZD0iTTgxLjA3IDI5LjIwMWExLjkzNCAxLjkzNCAwIDAxLTEuOTMyIDEuOTMySDQuODY1QTEuOTM0IDEuOTM0IDAgMDEyLjkzMyAyOS4ydi0zLjA5NGMwLTEuMDY1Ljg2Ny0xLjkzMiAxLjkzMi0xLjkzMkg1OS45NGExLjIxNiAxLjIxNiAwIDAwMC0yLjQzMUgxNS42OFY4LjY2bDQuMDM0IDIuMDE3YTYuNDEgNi40MSAwIDAwMi44NTMuNjc0aDExLjMzYy45ODYgMCAxLjk3My0uMjMzIDIuODU0LS42NzRsNC4wMzQtMi4wMTd2MTAuNzMzYTEuMjE2IDEuMjE2IDAgMDAyLjQzMiAwVjguNjZsNC4wMzUgMi4wMTdhNi40MSA2LjQxIDAgMDAyLjg1My42NzRoMTEuMzNjLjk4NiAwIDEuOTczLS4yMzMgMi44NTMtLjY3NGw0LjAzNS0yLjAxN3YxMy4wODNoLTMuNzhhMS4yMTYgMS4yMTYgMCAwMDAgMi40MzJoMTQuNTk1YzEuMDY1IDAgMS45MzEuODY3IDEuOTMxIDEuOTMxem0tMS41NzQgMzEuNTI0YTEuOTM0IDEuOTM0IDAgMDEtMS45MzIgMS45MzJINTkuMzk3YzguMDg3LTQuNTc2IDE0LjQzMi0xNS4yNjggMTYuNjU4LTI5LjA5M2gzLjA4M2MuMTIgMCAuMjQtLjAwNi4zNTgtLjAxNnptLTEuNzMxIDkuNDQyYzAgLjE5Ny0uMTYuMzU4LS4zNTguMzU4SDQ5LjMwM2MtMi4yNzMgMC00LjU2MS0uMTktNi44MDItLjU2M2wtMi40ODgtLjQxNWE0My45MzcgNDMuOTM3IDAgMDAtNy4yMDItLjU5Nkg2LjU5NmEuMzU4LjM1OCAwIDAxLS4zNTgtLjM1OHYtMy41MWMuMDY2LjAwMy4xMzMuMDA1LjIuMDA1SDE3LjYxYTEuMjE2IDEuMjE2IDAgMTAwLTIuNDMxSDYuNDM4YTEuOTM0IDEuOTM0IDAgMDEtMS45MzEtMS45MzJWMzMuNTQ4Yy4xMTguMDEuMjM3LjAxNi4zNTguMDE2aDY0LjA1M2MtMi44ODMgNC4zNjItOC4yODUgOC4yOTUtMTUuNDY1IDExLjIxMi04LjUyMSAzLjQ2Mi0xOC43OTMgNS4yOTItMjkuNzA1IDUuMjkyYTEuMjE2IDEuMjE2IDAgMDAwIDIuNDMxYzExLjIyMyAwIDIxLjgxMS0xLjg5MSAzMC42Mi01LjQ3IDguMzMxLTMuMzg1IDE0LjQ2OC04LjE0NiAxNy4zODgtMTMuNDY1aDEuODM0Yy0xLjM2NyA4LjEzLTQuMzI3IDE1LjQ0OC04LjM4OSAyMC42OTYtNC4yNTIgNS40OTMtOS4zMzYgOC4zOTctMTQuNzAyIDguMzk3SDIyLjAxN2ExLjIxNiAxLjIxNiAwIDAwMCAyLjQzMWg1NS41NDdjLjA2OCAwIC4xMzQtLjAwMi4yLS4wMDV6bS0xLjU3NCAxMC45aC0zLjg2M3YtMy44MmMwLS42Ny0uNTQ0LTEuMjE1LTEuMjE1LTEuMjE1SDEyLjg5Yy0uNjcyIDAtMS4yMTYuNTQ0LTEuMjE2IDEuMjE2djMuODJINy44MTF2LTkuNjg1aDI1YzIuMjczIDAgNC41NjEuMTg5IDYuODAzLjU2M2wyLjQ4Ny40MTRjMi4zNzMuMzk2IDQuNzk2LjU5NiA3LjIwMi41OTZINzYuMTl6TTcuNjU0IDguMDFjMC0yLjggMi4yNzgtNS4wNzggNS4wNzgtNS4wNzhINzEuMjdjMi44IDAgNS4wNzggMi4yNzggNS4wNzggNS4wNzh2MTMuNzMzaC01LjU5M1Y4LjA4NWMwLS43MjUtLjM2OC0xLjM4NS0uOTg1LTEuNzY2YTIuMDYyIDIuMDYyIDAgMDAtMi4wMi0uMDkxTDYzLjIgOC41MDJhMy45NjYgMy45NjYgMCAwMS0xLjc2NS40MTdoLTExLjMzYTMuOTcgMy45NyAwIDAxLTEuNzY2LS40MTdMNDMuNzkgNi4yMjhhMi4wNiAyLjA2IDAgMDAtMS43ODktLjAzMiAyLjA2IDIuMDYgMCAwMC0xLjc4OS4wMzJsLTQuNTQ5IDIuMjc0YTMuOTY2IDMuOTY2IDAgMDEtMS43NjUuNDE3SDIyLjU2N2EzLjk3IDMuOTcgMCAwMS0xLjc2Ni0uNDE3bC00LjU0OC0yLjI3NGEyLjA2MyAyLjA2MyAwIDAwLTIuMDIuMDkgMi4wNjMgMi4wNjMgMCAwMC0uOTg1IDEuNzY3djEzLjY1OEg3LjY1NHpNNzguNzggMjEuNzQzVjguMDFjMC00LjE0LTMuMzY5LTcuNTEtNy41MS03LjUxSDEyLjczMmMtNC4xNCAwLTcuNTEgMy4zNy03LjUxIDcuNTF2MTMuNzMzaC0uMzU3YTQuMzY4IDQuMzY4IDAgMDAtNC4zNjMgNC4zNjN2My4wOTVjMCAxLjM0Ni42MTIgMi41NSAxLjU3MyAzLjM1MnYyOC4xNzJjMCAxLjQxOC42OCAyLjY4IDEuNzMxIDMuNDc3djQuMzkxQTIuNzkgMi43OSAwIDAwNS4zOCA3MS4xdjEwLjM5NmMwIDEuMTA1Ljg5OCAyLjAwMyAyLjAwMiAyLjAwM2g0LjcyMWEyLjAwNSAyLjAwNSAwIDAwMi4wMDMtMi4wMDN2LTMuMDMzaDU1Ljc5djMuMDMzYzAgMS4xMDUuOSAyLjAwMyAyLjAwNCAyLjAwM2g0LjcyYTIuMDA1IDIuMDA1IDAgMDAyLjAwMy0yLjAwM3YtOC44MjNhMi43OSAyLjc5IDAgMDAxLjU3NC0yLjUwNnYtNS45NjVhNC4zNTggNC4zNTggMCAwMDEuNzMtMy40NzdWMzIuNTUzYTQuMzU1IDQuMzU1IDAgMDAxLjU3NC0zLjM1MnYtMy4wOTRhNC4zNjkgNC4zNjkgMCAwMC00LjM2My00LjM2NHoiLz48L3N2Zz4=) no-repeat;

                        background-size: cover;

                        width: 85px;

                        height: 85px;

                        margin: 0 auto;

                    }

                    #vuanem-header .body-no-result .description-no-result {

                        text-align: center;

                        color: #505050;

                        font-size: 18px;

                        line-height: 26px;

                        margin-top: 30px;

                    }

                </style>

                <div class="header-center">

                    <div class="container">

                        <div class="content-header">

                            <div class="header-bottom-mobile mobile ">

                                <div class="sidebar-mobile">

                                    <div class="icons-menu">

                                        <div class="line"></div>

                                        <div class="line"></div>

                                        <div class="line"></div>

                                    </div>

                                </div>



                            </div>

                            <div class="logo-header desktop">

                                <a href="<?php echo base_url() ?>"><img

                                            src="<?php echo $this->fcSystem['homepage_logo'] ?>"

                                            alt="<?php echo $this->fcSystem['homepage_company'] ?>"

                                            width="150" class="main-logo"></a>

                            </div>

                            <div class="main-menu desktop">

                                <div class="widget block block-static-block">

                                    <div class="cdz-main-menu">

                                        <div class="cdz-menu cdz-horizontal-menu cdz-normal">

                                            <ul class="groupmenu">



                                                <style>

                                                    #vuanem-header .main-menu .cdz-horizontal-menu > ul > li.level-top {

                                                        padding-bottom: 0 !important;
                                                        flex: auto;


                                                    }



                                                    #vuanem-header .main-menu .cdz-horizontal-menu > ul > li.level-top img {

                                                        margin: 0px auto;

                                                        height: 25px;

                                                        object-fit: contain;



                                                    }

                                                </style>





                                                <?php if (isset($main_nav) && is_array($main_nav) && count($main_nav)) { ?>

                                                    <?php $i = 0;

                                                    foreach ($main_nav as $key => $val) {

                                                        $i++; if($i<=$this->fcSystem['homepage_count_menu']){?>







                                                            <li class="item level0 position-static level-top parent">



                                                                <a class="menu-link" href="<?php echo $val['link']; ?>">



                                                                    <i class="menu-icon img-icon"> <img

                                                                                src="<?php echo $val['image']; ?>"

                                                                                alt="<?php echo $val['title']; ?>"></i>

                                                                    <span><?php echo $val['title']; ?></span>

                                                                </a>

                                                                <?php if (isset($val['children']) && is_array($val['children']) && count($val['children'])) { ?>



                                                                    <ul class="groupmenu-drop">

                                                                        <li class="item level1 has-submenu text-content">

                                                                            <div class="has-submenu groupmenu-drop-content groupmenu-width-24"

                                                                                 style=" ">

                                                                                <div class="row">



                                                                                    <?php foreach ($val['children'] as $keyC => $valC) {

                                                                                        if ($valC['title'] != 'Thương hiệu') { ?>

                                                                                            <div class="col-sm-4">

                                                                                                <p class="groupdrop-title font-bold-stag"><?php echo $valC['title']; ?>

                                                                                                    <span class="dropdown-icon"><i

                                                                                                                class="fa fa-angle-right"></i></span>

                                                                                                </p>

                                                                                                <?php if (isset($valC['children']) && is_array($valC['children']) && count($valC['children'])) { ?>



                                                                                                    <ul class="groupdrop-link">

                                                                                                        <?php foreach ($valC['children'] as $keyCC => $valCC) { ?>

                                                                                                            <li class="item">

                                                                                                                <a href="<?php echo $valCC['link']; ?>"

                                                                                                                   <?php if ($valCC['ishome'] == 1){ ?>style="color: #ff0000;"<?php } ?>><?php echo $valCC['title']; ?> <?php if ($valCC['ishome'] == 1) { ?>

                                                                                                                        <span class="label-hot">HOT</span><?php } ?>

                                                                                                                </a>

                                                                                                            </li>

                                                                                                        <?php } ?>

                                                                                                    </ul>

                                                                                                <?php } ?>

                                                                                            </div>

                                                                                        <?php } ?>

                                                                                    <?php } ?>



                                                                                    <?php foreach ($val['children'] as $keyC => $valC) {

                                                                                        if ($valC['title'] == 'Thương hiệu') { ?>



                                                                                            <div class="col-sm-8">

                                                                                                <p class="groupdrop-title font-bold-stag"> <?php echo $valC['title'] ?>

                                                                                                    <span class="dropdown-icon"><i

                                                                                                                class="fa fa-angle-right"></i></span>

                                                                                                </p>

                                                                                                <?php if (isset($valC['children']) && is_array($valC['children']) && count($valC['children'])) { ?>



                                                                                                    <ul class="groupdrop-link banner-brand">

                                                                                                        <?php foreach ($valC['children'] as $keyCC => $valCC) { ?>



                                                                                                            <li class="item">

                                                                                                                <a href="<?php echo $valCC['link']; ?>"><img

                                                                                                                            src="<?php echo $valCC['image']; ?>"

                                                                                                                            width="88"

                                                                                                                            height="88"></a>

                                                                                                            </li>

                                                                                                        <?php } ?>



                                                                                                    </ul>

                                                                                                <?php } ?>



                                                                                            </div>

                                                                                        <?php } ?>

                                                                                    <?php } ?>





                                                                                </div>

                                                                            </div>

                                                                        </li>

                                                                    </ul>

                                                                <?php } ?>



                                                            </li>



                                                    <?php } ?>

                                                    <?php } ?>



                                                <?php } ?>



                                                <?php /*<li class="item level0  level-top">



                                                    <a class="menu-link"

                                                       href="<?php echo $this->fcSystem['menu_link_tl'] ?>">

                                                        <i class="menu-icon img-icon"><img

                                                                    src="<?php echo $this->fcSystem['menu_icon_tl'] ?>"></i>

                                                        <span><span style="color:red"><?php echo $this->fcSystem['menu_title_tl'] ?></span></span>

                                                    </a>

                                                </li>

                                                <li class="item level0 mobile color-red level-top">

                                                    <a class="menu-link"

                                                       href="<?php echo $this->fcSystem['menu_link_tkm'] ?>">

                                                        <i class="menu-icon img-icon"><img

                                                                    src="<?php echo $this->fcSystem['menu_icon_km'] ?>"

                                                                    alt="<?php echo $this->fcSystem['menu_title_km'] ?>"></i><span><?php echo $this->fcSystem['menu_title_km'] ?></span>

                                                    </a>

                                                </li>*/ ?>





                                            </ul>

                                        </div>



                                    </div>

                                </div>

                            </div>

                            <div class="search-bar">



                                <div class="logo-header mobile">

                                    <a href="<?php echo base_url() ?>"><img src="<?php echo $this->fcSystem['homepage_logo'] ?>" alt="<?php echo $this->fcSystem['homepage_company'] ?>" width="60"

                                                class="main-logo"></a>

                                </div>

                                <div class="search-form-container">





                                    <div class="block-icon-seach"><i class="fa fa-search"></i></div>



                                    <form id="search_mini_form" action="tim-kiem.html" method="get"

                                          class="form minisearch has-cat">

                                        <div class="field search">

                                            <div class="control">

                                                <input id="search" value="" type="text" name="keyword"

                                                       placeholder="Tìm kiếm" autocomplete="off" class="input-text">

                                            </div>

                                        </div>

                                        <div class="actions">

                                            <button type="submit" title="Tìm kiếm" class="action search primary"><i

                                                        class="fa fa-search"></i></button>

                                        </div>

                                    </form>

                                    <div id="bodyFull" class="fullBody"></div>

                                    <div class="v-autocomplete">



                                    </div>

                                </div>

                            </div>

                            <?php /*<div class="store-location desktop">

                                <a href="stores.html"><img

                                            src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMC44MDUiIHZpZXdCb3g9IjAgMCAzMiAzMC44MDUiPgogIDxnIGlkPSJpY29uX2xvY2F0aW9uIiBkYXRhLW5hbWU9Imljb24gbG9jYXRpb24iIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDE4IC01MC4xOTUpIj4KICAgIDxnIGlkPSJFbGxpcHNlXzkxIiBkYXRhLW5hbWU9IkVsbGlwc2UgOTEiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwMjUgNzEpIiBmaWxsPSIjZmZmIiBzdHJva2U9IiMyOTJiYjciIHN0cm9rZS13aWR0aD0iMSIgb3BhY2l0eT0iMC41Ij4KICAgICAgPGVsbGlwc2UgY3g9IjkiIGN5PSIzLjUiIHJ4PSI5IiByeT0iMy41IiBzdHJva2U9Im5vbmUiLz4KICAgICAgPGVsbGlwc2UgY3g9IjkiIGN5PSIzLjUiIHJ4PSI4LjUiIHJ5PSIzIiBmaWxsPSJub25lIi8+CiAgICA8L2c+CiAgICA8ZyBpZD0iRWxsaXBzZV85MiIgZGF0YS1uYW1lPSJFbGxpcHNlIDkyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDE4IDY4KSIgZmlsbD0iI2ZmZiIgc3Ryb2tlPSIjMjkyYmI3IiBzdHJva2Utd2lkdGg9IjEiIG9wYWNpdHk9IjAuNSI+CiAgICAgIDxlbGxpcHNlIGN4PSIxNiIgY3k9IjYuNSIgcng9IjE2IiByeT0iNi41IiBzdHJva2U9Im5vbmUiLz4KICAgICAgPGVsbGlwc2UgY3g9IjE2IiBjeT0iNi41IiByeD0iMTUuNSIgcnk9IjYiIGZpbGw9Im5vbmUiLz4KICAgIDwvZz4KICAgIDxwYXRoIGlkPSJQYXRoXzI3IiBkYXRhLW5hbWU9IlBhdGggMjciIGQ9Ik02Ni42MDYsMGE5LjQ1NSw5LjQ1NSwwLDAsMC05LjQ1NSw5LjQ1NWMwLDcuNTcxLDguNTQ3LDE0LjU4Myw4LjU0NywxNC41ODNhMS41LDEuNSwwLDAsMCwxLjgxNiwwczguNTQ3LTcuMDEyLDguNTQ3LTE0LjU4M0E5LjQ1NSw5LjQ1NSwwLDAsMCw2Ni42MDYsMFptMCwxNC4yMTJhNC43NTcsNC43NTcsMCwxLDEsNC43NTctNC43NTdBNC43NjIsNC43NjIsMCwwLDEsNjYuNjA2LDE0LjIxMloiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDk2Ny42NDUgNTAuMTk1KSIgZmlsbD0iIzI5MmJiNyIvPgogIDwvZz4KPC9zdmc+Cg==">

                                    <div class="label-store">Tìm cửa hàng<span>quanh đây</span></div>

                                </a>

                            </div>

                            <div class="information-websites desktop">

                                <div class="items-link phone"><p class="title">Mua hàng, gọi ngay</p> <a

                                            href="tel:<?php echo $this->fcSystem['contact_hotline'] ?>"

                                            class="content"><?php echo $this->fcSystem['contact_hotline'] ?></a></div>

                            </div>*/?>

                        </div>

                    </div>

                </div> <!---->

            <?php } ?>





            <?php /*<div class="sale-redline">

                <p style="text-align: center; line-height: 2; margin-bottom: 0px;">

                    <a href="<?php echo $this->fcSystem['link_link_bst'] ?>"

                       style="font-size: medium; font-family: arial, helvetica, sans-serif;color: #fff">

                        <?php echo $this->fcSystem['link_bst'] ?>n - <span

                                style="text-decoration: underline">Xem ngay</span>

                    </a>



                </p>

            </div>*/?>

        </div>

    </div>



</div>

